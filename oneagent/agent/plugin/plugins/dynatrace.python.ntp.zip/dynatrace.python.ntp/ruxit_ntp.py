from ruxit.api.data import PluginMeasurement
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.exceptions import ConfigException
from ruxit.api.selectors import HostSelector

# generic
import os
import platform
import random
import re
import time
from time import ctime

# drivers
import ntplib
import logging
log = logging.getLogger(__name__)

def get_system_ntp_servers():
    if platform.system() == 'Windows':
        import winreg
        reg = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
        key = winreg.OpenKey(reg, r"System\CurrentControlSet\Services\W32Time\Parameters")
        config = winreg.QueryValueEx(key, "NtpServer")
        config = re.split("[,;|]", config[0])
        return config
    else:
        with open("/etc/ntp.conf") as config_file:
            ntp_config = config_file.readlines()
            lines = filter(lambda l: l.startswith("pool") or l.startswith("server"), ntp_config)
            return map(lambda l: l.split()[1], lines)

class NtpPlugin(BasePlugin):
    def initialize(self, **kwargs):
        config = kwargs['config']
        self.timeseries = kwargs['json_config']['metrics']
        self.associated_entity = kwargs['associated_entity']
        self.servers = []
        self.responding_server = None
        self.ntpclient = ntplib.NTPClient()
        
        if 'ntp_server' in config and len(config['ntp_server']):
            self.servers = config['ntp_server'].split(',')
            log.info("ntplog: Servers found in manual configuration: " + self.servers.__str__())
        else:
            log.info("ntplog: No servers found in manual configuration. ")
        
        self.port = 'ntp'
        if 'ntp_port' in config and len(config['ntp_port']):
            self.port = int(config['ntp_port'])
            log.info("ntplog: Port found in manual configuration: " + self.port.__str__())
        else:
            self.port = 123
            log.info("ntplog: No port found in manual configuration. ")
            log.info("ntplog: Port set to default: 123. ")

        # 2.013 - only pull in OS servers in the lack of explicit config
        if len(self.servers) == 0:
            log.info("ntplog: Attempting autoconfiguration: ")
            try:
                self.servers = get_system_ntp_servers()
                log.info("ntplog: Servers found by autoconfiguration:" + self.servers.__str__())
            except Exception as e:
                log.info("ntplog: Failed to get OS NTP config")
                log.info("ntplog: Encountered exception: " + e.__str__())
                raise ConfigException("'ntp_server' field is not present in configuration and autoconfiguration failed")

        self.servers = list(filter(len, self.servers))

        if len(self.servers) == 0:
            log.info("ntplog: No servers left after 0-length filtering")
            raise ConfigException("'ntp_server' field is not present in configuration and autoconfiguration failed")

        self.ntp_version = config.get('ntp_version', 3)

    def query(self, **kwargs):
        if self.responding_server is None:
            server = random.choice(self.servers)
        else:
            server = self.responding_server
        try:
            response = self.ntpclient.request(server, version=3, port=self.port)
            self.results_builder.add_absolute_result(PluginMeasurement(
                key='ntp_offset',
                value=response.offset,
                entity_selector=HostSelector()
            ))
            log.info("ntplog: Success getting time from server: " + server)
            self.responding_server = server
        except Exception as e:
            self.responding_server = None
            log.info("ntplog: Failed getting time from server: " + server)
            log.info("ntplog: Encountered exception: " + e.__str__())
            raise Exception("Failed getting time from server: " + server)