from collections import Counter, defaultdict
from collections import namedtuple
from contextlib import contextmanager
from distutils.version import LooseVersion
import json
from itertools import groupby
import logging
from typing import List
from ruxit.api.data import PluginMeasurement, PluginProperty, MEAttribute
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.exceptions import ConfigException
from ruxit.api.snapshot import parse_port_bindings
from ruxit.api.selectors import ExplicitPgiSelector, DockerSelector
from docker.errors import DockerException
import ruxit.api.selectors
from platform import system
from datetime import datetime
import re

import async_docker

log = logging.getLogger(__name__)

CpuUsage = namedtuple('CpuUsage', ['total', 'system'])
DockerContainerDesc = namedtuple('DockerContainerDesc', ['container_id', 'image_version', 'container_group_instance_id'])
GlobalDockerData = namedtuple('GlobalDockerData', ['running_ids', 'image_map'])


class VersionChecker:
    def __init__(self):
        self.checked = False
        self.supported = None
        self.version = None


class DockerPlugin(BasePlugin):

    STATS_COLLECTING_TIME = 55  # plugin loop is 60s, but lets give a 5s safety margin, so all stats will be ready
    # flag to print DockerExdceptio only once in plug-in life
    docker_exception_logged = False
    multipliers = {'TB': 10 ** 12, 'GB': 10 ** 9, 'MB': 10 ** 6, 'KB': 10 ** 3, 'B': 1}
    
    def initialize(self, **kwargs):
        self.last_cpu_times = {}
        self.last_docker_cont_ids_of_dcgi = {}
        self.timeouted_containers = set()
        self.entity = kwargs['associated_entity']
        self.docker_host = self.__get_dockerhost()
        self.__base_url = None
        DockerPlugin.docker_exception_logged = False
        self.version_checker = VersionChecker()
        self.client = None

        # query strategy is: synchronous -> windows, asynchronous -> all the rest
        self.use_synchronous_strategy = True if system() == 'Windows' else False

    def __get_dockerhost(self):
        if system() == 'Windows':
            return None
        for process in self.entity.processes:
            cmd_line = process.properties.get('CmdLine', '')
            docker_host = re.search("(--host|-H)[\t ]+unix://[^\s]*", cmd_line)
            if docker_host:
                param_value = docker_host.group().split()
                if len(param_value) > 1:
                    log.info("docker_host set to " + param_value[1])
                    return param_value[1]

    def __get_client(self):
        try:
            return async_docker.ExtendedAPIClient(base_url=self.get_base_url(), version='auto', timeout=15, num_pools=2)
        except DockerException:
            for endpoint in self.get_possible_endpoints():
                try:
                    self.__set_base_url(endpoint)
                    return async_docker.ExtendedAPIClient(base_url=endpoint, version='auto', timeout=15, num_pools=2)
                except DockerException as de:
                    if not DockerPlugin.docker_exception_logged:
                        log.info("Docker exception for endpoint %s %s", self.get_base_url(), de)

            DockerPlugin.docker_exception_logged = True 
            raise Exception("Docker API error. Docker setup is possibly not supported or pluginagent has not enough permission to access docker socket")

    def __check_version(self):
        if not self.version_checker.checked:
            self.version_checker.version = self.client.version().get("Version", None)
            self.version_checker.checked = self.version_checker.version is not None
            if not self.version_checker.version:
                self.version_checker.version = "unknown version"
                self.version_checker.supported = False
            else:
                self.version_checker.supported = LooseVersion("1.8.0") <= LooseVersion(self.version_checker.version)

        if not self.version_checker.supported:
            raise ConfigException("Docker version ( {} ) is not supported (minimum is 1.8.0)"
                                  .format(self.version_checker.version))

    @contextmanager
    def save_containers_data(self, running_container_ids):
        yield
        # remove old CPU times
        self.last_cpu_times = {k:v for (k, v) in self.last_cpu_times.items() if k in running_container_ids}
        self.client.close()

    def query(self, **kwargs):
        running_container_ids = set()
        self.client = self.__get_client()

        with self.save_containers_data(running_container_ids):
            DockerPlugin.docker_exception_logged = False  # If we reconnect and lose connection after, we want to log new reason
            self.__check_version()  # versions1.8.0 and above is supported by plugin

            process_snapshot = kwargs['process_snapshot']
            docker_containers, docker_cont_ids_of_dcgi = self.containers_from_snapshot(process_snapshot)
            self.containers_launched_and_terminated(docker_cont_ids_of_dcgi)
            self.containers_per_pgi_from_snapshot(process_snapshot.containers)
            docker_data = self.get_base_docker_data()

            # As far as there is no npipe:// support in aiohttp, asynchronous strategy should not be used on Windows
            if self.use_synchronous_strategy:
                self.synchronous_strategy(docker_containers, docker_data, running_container_ids)
            else:
                self.asynchronous_strategy(docker_containers, docker_data, running_container_ids)

    def synchronous_strategy(self, docker_containers, docker_data, running_container_ids):
        retries = 3
        timeouted_containers = set()

        timeout_nr = 0
        for containers in docker_containers:
            self.get_per_version_tag_metrics(containers, docker_data.running_ids)
            self.move_timeouted_containers_to_end(containers)
            for container_desc in containers:
                if not self.get_timeseries_and_properties(container_desc, docker_data.image_map):
                    timeouted_containers.add(container_desc.container_id)
                    timeout_nr += 1
                    if timeout_nr >= retries:
                        return
                running_container_ids.add(container_desc.container_id)
        self.timeouted_containers = timeouted_containers

    def asynchronous_strategy(self, docker_containers, docker_data, running_container_ids):
        containers_ids = set(cont.container_id for containers in docker_containers for cont in containers)
        if len(containers_ids)>0:
            query_interval = DockerPlugin.STATS_COLLECTING_TIME
            containers_stats = self.client.multi_stats(containers_ids, query_interval=query_interval)

            for containers in docker_containers:
                self.get_per_version_tag_metrics(containers, docker_data.running_ids)
                for container_desc in containers:
                    res = self.get_timeseries_and_properties(container_desc, docker_data.image_map, containers_stats=containers_stats)
                    if not res:
                        log.info("No data for container:{}".format(container_desc.container_id))
                    running_container_ids.add(container_desc.container_id)

            log.info("Containers count: {}".format(len(running_container_ids)))
            return
        else:
            log.info("Not running containters")
 

    def get_possible_endpoints(self):
        if system() == 'Windows':
            endpoints = ['npipe:////./pipe/docker_engine', 'npipe:////./pipe/docker_engine_windows']
        else:
            endpoints = ['unix://var/run/docker.sock', 'unix://var/run/docker/docker.sock']
            if self.docker_host:
                endpoints.insert(0, self.docker_host)
            port_bindings = parse_port_bindings (self.entity)
            if len(port_bindings) != 0:
                endpoints.append('http://{0}:{1}'.format(port_bindings[0][0], port_bindings[0][1]))
        return endpoints

    def get_base_url(self):
        if not self.__base_url:
            self.__base_url = self.get_possible_endpoints()[0]
        return self.__base_url
    
    def __set_base_url(self, new_url):
        self.__base_url = new_url
        
    # move timeouted containers to the end of the list
    def move_timeouted_containers_to_end(self, containers):
        if len(self.timeouted_containers) == 0:
            return

        containers_len = len(containers)
        timeouted_index = containers_len
        for i in range(containers_len):
            if i >= timeouted_index:
                return
            if containers[i].container_id in self.timeouted_containers:
                timeouted_index -= 1  
                containers[i], containers[timeouted_index] = containers[timeouted_index], containers[i]

    def containers_per_pgi_from_snapshot(self, containers):
        all_pgis_occurences = []
        for cont in containers:
            all_pgis_occurences.extend(cont.group_instance_ids)

        no_of_containers_per_pgi = (Counter(all_pgis_occurences)).most_common()

        for pgi_tuple in no_of_containers_per_pgi:
            self.results_builder.add_absolute_result(
                PluginMeasurement(
                    entity_selector=ExplicitPgiSelector(pgi_tuple[0]),
                    key='no_of_containers_per_pgi',
                    value=pgi_tuple[1]
                )
            )

    def containers_launched_and_terminated(self, docker_cont_ids_of_dcgi):
        first_run = not bool(self.last_docker_cont_ids_of_dcgi)
        if not first_run:
            for dcgi, cont_ids in docker_cont_ids_of_dcgi.items():
                cont_ids_set = set(cont_ids)
                last_cont_ids_set = set(self.last_docker_cont_ids_of_dcgi.get(dcgi, set([])))

                launched = cont_ids_set.difference(last_cont_ids_set)
                terminated = last_cont_ids_set.difference(cont_ids_set)

                self.results_builder.add_absolute_result(
                    PluginMeasurement(
                        entity_selector=ExplicitPgiSelector(dcgi),
                        key='no_of_containers_launched',
                        value=len(launched)
                    )
                )
                self.results_builder.add_absolute_result(
                    PluginMeasurement(
                        entity_selector=ExplicitPgiSelector(dcgi),
                        key='no_of_containers_terminated',
                        value=len(terminated)
                    )
                )

            for last_dcgi, last_cont_ids in self.last_docker_cont_ids_of_dcgi.items():
                if last_dcgi not in docker_cont_ids_of_dcgi:
                    terminated = len(last_cont_ids)

                    self.results_builder.add_absolute_result(
                        PluginMeasurement(
                            entity_selector=ExplicitPgiSelector(last_dcgi),
                            key='no_of_containers_terminated',
                            value=terminated
                        )
                    )
        self.last_docker_cont_ids_of_dcgi = docker_cont_ids_of_dcgi

    def containers_from_snapshot(self, process_snapshot):
        docker_containers = defaultdict(list)
        docker_cont_ids_of_dcgi = defaultdict(list)
        for cont in process_snapshot.containers:
            docker_containers[cont.docker_container_group_instance_id].append(
                DockerContainerDesc(cont.container_id, cont.container_image_version, cont.docker_container_group_instance_id))
            docker_cont_ids_of_dcgi[cont.docker_container_group_instance_id].append(cont.container_id)

        return docker_containers.values(), docker_cont_ids_of_dcgi

    def get_base_docker_data(self):
        results = GlobalDockerData(running_ids=[cont_runn['Id'] for cont_runn in self.client.containers(quiet=True)],
                                   image_map={i.get('Id'): (i.get('Created'), i.get('VirtualSize')) for i in self.client.images()})

        docker_info = self.client.info()
        filesystem_driver = docker_info.get('Driver', 'unknown')
        if filesystem_driver == 'devicemapper':
            self.get_devicemapper_stats(docker_info['DriverStatus'])
            loopback_tags = ['Data loop file', 'Metadata loop file']
            for loopback_tag in loopback_tags:
                if loopback_tag in [stat[0] for stat in docker_info['DriverStatus']]:
                    filesystem_driver = 'devicemapper-loopback'
                    break;

        self.results_builder.add_property(PluginProperty(
                entity_selector=ruxit.api.selectors.HostSelector(),
                key='ruxit.python.docker.filesystem_driver',
                value=filesystem_driver,
                me_attribute=MEAttribute.INTERNAL_DEBUG_PROPERTY
            )
        )
        return results


    __devicemapper_metrics = (('devicemapper_data_space_used', 'Data Space Used'),
        ('devicemapper_metadata_space_used', 'Metadata Space Used'),
        ('devicemapper_data_space_available', 'Data Space Available'),
        ('devicemapper_metadata_space_available', 'Metadata Space Available')
    )

    def get_devicemapper_stats(self, driver_status):
        for devicemapper_metric in DockerPlugin.__devicemapper_metrics:
            devicemapper_metric_desc = [stat[1] for stat in driver_status if stat[0] == devicemapper_metric[1]]
            if len(devicemapper_metric_desc) == 1:
                value_converted = DockerPlugin.convert_string_to_byte(devicemapper_metric_desc[0])
                value_converted is not None and self.results_builder.add_absolute_result(PluginMeasurement(
                    entity_selector=ruxit.api.selectors.HostSelector(),
                    key=devicemapper_metric[0],
                    value=int(value_converted)))

    #convert size string with units into 2 elements table
    #'12.1 GB' -> ['12.1','GB']
    #'12.1GB' -> ['12.1','GB']  
    @staticmethod
    def smart_split(value: str) -> List[str]:
        result = []
        for is_word, word in groupby(value, lambda c: c.isdigit() or c == '.'):
            if is_word:
                result.append(''.join(word))
            else:
                result.append(''.join(c for c in word if c.isalpha()))
        return result
        
    #get size in bytes from size string
    #'12.1 GB' -> 12100000000
    @staticmethod
    def convert_string_to_byte(value: str) -> float:
        split_string = DockerPlugin.smart_split(value)
        if len(split_string) == 2:
            multiplier = DockerPlugin.multipliers.get(split_string[1].upper())
            if multiplier:
                return float(split_string[0]) * float(multiplier)
            else:
                log.info('Multiplier ' + split_string[1] + ' is not supported')
        else:            
            return float(split_string[0])

    def get_timeseries_and_properties(self, container_desc, image_map, containers_stats=None):
        container_id = container_desc.container_id
        image_version = container_desc.image_version

        if self.use_synchronous_strategy:
            try:
                one_stat = self.client.stats(container=container_id, stream=False, decode=True)
                if len(one_stat) == 0:
                    raise Exception
                inspect_obj = self.client.inspect_container(container_id)
            except:
                log.info("Could not extract data for container %s", container_id, exc_info=1)
                return False
        else:
            if not containers_stats:
                return False
            stats = None
            try:
                stats = next(stat for stat in containers_stats if stat['container_id'] == container_id)
            except StopIteration:
                log.debug("Could not extract data for container %s", container_id, exc_info=1)
                return False
            one_stat = stats['main_stats']
            inspect_obj = stats['inspect_stats']

        dim = {'container_id': container_id}
        selector = DockerSelector(container_desc.container_group_instance_id)

        self.get_timeseries(selector, container_id, dim, one_stat, inspect_obj)
        self.get_properties(selector, container_id, inspect_obj, image_version, image_map)
        return True

    def calculate_network_bytes(self, networks):
        net_aggregates = Counter()
        for eth, eth_stats in networks.items():
            net_aggregates.update(eth_stats)  
        return net_aggregates['rx_bytes'], net_aggregates['tx_bytes']

    def get_per_version_tag_metrics(self, containers, running_ids):
        try:
            container_group_instance_id = containers[0].container_group_instance_id
            running_versions = []

            for cont in containers:
                if cont.container_id in running_ids:
                    running_versions.append(cont.image_version)

            tag_numbers = Counter(running_versions)

            for tag, number in tag_numbers.items():
                dim = {'version_tag': tag}
                self.results_builder.add_absolute_result(PluginMeasurement(
                    entity_selector=DockerSelector(container_group_instance_id),
                    key='no_of_containers_running',
                    dimensions=dim,
                    value=number
                    )
                )
        except:
            log.info(self, exc_info=1)

    def get_cpu_times_linux(self, one_stat):
        total_cpu = one_stat.get('cpu_stats', {}).get('cpu_usage', {}).get('total_usage', 'n/a')
        system_cpu = one_stat.get('cpu_stats', {}).get('system_cpu_usage', 'n/a')
        return CpuUsage(total_cpu, system_cpu)
            
    def get_cpu_times_windows(self, one_stat, last_cpu_system):
        total_cpu =  one_stat.get('cpu_stats', {}).get('cpu_usage', {}).get('total_usage', 'n/a')
        system_cpu = 'n/a'
           
        iso_format = '%Y-%m-%dT%H:%M:%S.%f'
        read = one_stat.get('read', 'n/a')
        preread = one_stat.get('preread', 'n/a')
        num_procs = one_stat.get('num_procs', 'n/a')
        if read != 'n/a' and preread != 'n/a' and num_procs != 'n/a':
            try:
                # precision varies from 5 to 7 decimal places; 5 is more than enough for us
                read_dt = datetime.strptime(read[:25], iso_format)
                preread_dt = datetime.strptime(preread[:25], iso_format)
                system_cpu_time_seconds = read_dt.timestamp() - preread_dt.timestamp()
                system_cpu_time_nanoseconds = int(system_cpu_time_seconds * (10**9))
                system_cpu = last_cpu_system + system_cpu_time_nanoseconds * num_procs
            except:
                log.info(self, exc_info=1)
        return CpuUsage(total_cpu, system_cpu)

    def get_timeseries_cpu(self, selector, container_id, dim, one_stat):
        last_cpu_times = self.last_cpu_times.get(container_id, CpuUsage(0, 0))
        if system() == 'Windows':
            cpu_times = self.get_cpu_times_windows(one_stat, last_cpu_times.system)
        else:
            cpu_times = self.get_cpu_times_linux(one_stat)
        if cpu_times.total == 'n/a' or cpu_times.system == 'n/a':
            return
        system_delta = cpu_times.system - last_cpu_times.system
        if system_delta == 0:
            log.info("Invalid cpu stats: system time = 0")
            return
        percent_cpu = (cpu_times.total - last_cpu_times.total) / system_delta
        first_run = last_cpu_times.system == 0 or percent_cpu < 0
        self.last_cpu_times[container_id] = cpu_times
        if not first_run:
            self.results_builder.add_absolute_result(
                PluginMeasurement(
                    entity_selector=selector,
                    key='cpu_usage2',
                    dimensions=dim,
                    value=percent_cpu*100)
            )
        
    def get_timeseries(self, selector, container_id, dim, one_stat, inspect_obj):
        self.get_timeseries_cpu(selector, container_id, dim, one_stat)

        memory_limit = one_stat.get('memory_stats', {}).get('limit', 'n/a')
        if memory_limit == 0:
            memory_limit = 'n/a'
        if system() == 'Windows':
            memory_usage = one_stat.get('memory_stats', {}).get('privateworkingset', 'n/a')
            if memory_limit == 'n/a':
                memory_limit = inspect_obj.get('HostConfig', {}).get('Memory', 'n/a')
                if memory_limit == 0:
                    memory_limit = 'n/a'
        else:
            stats = one_stat.get('memory_stats', {}).get('stats', {})
            total_rss = stats.get('total_rss', 0)
            total_mapped_file = stats.get('total_mapped_file', 0)
            memory_usage = total_rss + total_mapped_file
            if memory_usage == 0:
                memory_usage = 'n/a'

        networks = one_stat.get('networks', 'n/a')
        if networks != 'n/a':
            rx_bytes, tx_bytes = self.calculate_network_bytes(networks)
        else:
            rx_bytes = one_stat.get('network', {}).get('rx_bytes', 'n/a')
            tx_bytes = one_stat.get('network', {}).get('tx_bytes', 'n/a')
        throttled_time = one_stat.get('cpu_stats', {}).get('throttling_data', {}).get('throttled_time', 'n/a')

        rx_bytes != 'n/a' and self.results_builder.add_per_second_result(
            PluginMeasurement(
                entity_selector=selector,
                key='bytes_rx2',
                dimensions=dim,
                value=rx_bytes
            )
        )
        tx_bytes != 'n/a' and self.results_builder.add_per_second_result(
            PluginMeasurement(
                entity_selector=selector,
                key='bytes_tx2',
                dimensions=dim,
                value=tx_bytes
            )
        )
        memory_usage != 'n/a' and self.results_builder.add_absolute_result(
            PluginMeasurement(
                entity_selector=selector,
                key='memory_usage2',
                dimensions=dim,
                value=memory_usage
            )
        )
        self._report_memory_percent(dim, memory_limit, memory_usage, selector)
        throttled_time != 'n/a' and self.results_builder.add_relative_result(
            PluginMeasurement(
                entity_selector=selector,
                key='throttled_time2',
                dimensions=dim,
                value=throttled_time / 10 ** 6
            )
        )

    def _report_memory_percent(self, dim, memory_limit, memory_usage, selector):
        if memory_usage != 'n/a' and memory_limit != 'n/a':
            memory_usage_int = int(memory_usage)
            memory_limit_int = int(memory_limit)
            if memory_limit_int >= memory_usage_int and memory_limit_int != 0:
                self.results_builder.add_absolute_result(PluginMeasurement(
                    entity_selector=selector,
                    key='memory_percent',
                    dimensions=dim,
                    value=100 * memory_usage_int / memory_limit_int
                ))
            else:
                log.info("Invalid memory stats: usage=%s, limit=%s", memory_usage_int, memory_limit_int)


    __discover_status = (('OOMKilled', 'OOMKilled'),
                        ('Paused', 'Paused'),
                        ('Running', 'Running'),
                        ('Restarting', 'Running')
                      )

    def get_properties(self, selector, container_id, inspect_obj, image_version, image_map):
        try:
            image_id = inspect_obj.get('Image', 'n/a')
            image_properties = image_map.get(image_id, ('n/a', 'n/a'))
            created = image_properties[0]
            virtual_size = image_properties[1]

            cpu_shares = inspect_obj.get('HostConfig', {}).get('CpuShares', 'n/a')
            memory = inspect_obj.get('HostConfig', {}).get('Memory', 'n/a')
            container_start_date = inspect_obj.get('State', {}).get('StartedAt', 'n/a')

            states = inspect_obj.get('State', {})
            collected_status = next((status[1] for status in DockerPlugin.__discover_status if states.get(status[0])), 'Exited')

            json_properties = {
                                'created': created,
                                'virtual_size': virtual_size,
                                'cpu_shares': cpu_shares,
                                'memory_limits': memory,
                                'state': collected_status,
                                'container_start_date': container_start_date,
                                'version_tag': image_version
                                }

            self.results_builder.add_property(PluginProperty(
                key = container_id, 
                value = json.dumps(json_properties), 
                entity_selector = selector,
                me_attribute = MEAttribute.DOCKER_CONTAINER_PROPS))
        except:
            log.info("Exception in DockerPlugin.get_properties", exc_info=1)
