import asyncio
import aiohttp
import docker
import time
import statistics
from docker.errors import DockerException
from docker.constants import DEFAULT_TIMEOUT_SECONDS, DEFAULT_NUM_POOLS
import os
import logging
from platform import system
from enum import Enum, auto

log = logging.getLogger(__name__)

def parseLogLevel( s ):
    if s == 'warn':
        return logging.WARNING
    elif s == 'debug':
        return logging.DEBUG
    else:
        return logging.INFO

LOGLEVEL_FILENAME = 'ruxit_python_docker.loglevel' 

def setLogLevel():
    new_loglevel = logging.INFO
    loglevel_file_path = os.getcwd()+ '/' + LOGLEVEL_FILENAME
    try:
        with open( loglevel_file_path,  'r') as loglevel_file:
            content = loglevel_file.read().strip()
            new_loglevel = parseLogLevel(content)
    except FileNotFoundError:
        pass
    if new_loglevel != log.level:
        log.setLevel(new_loglevel)

class FetchState(Enum):
    UNDEF = auto()
    OK = auto()
    FAIL = auto()
    FAIL_TIMEOUT = auto()
    FAIL_NOT_EXISTS = auto()

class FetchStatus:
    def __init__(self, what):
        self.url = None
        self.what = what
        self.start_time = None
        self.end_time = None
        self.state = FetchState.UNDEF
        self.data = None
        self.exception = None

    def get_time(self):
        if self.start_time is None or self.end_time is None:
            return 0.0
        else:
            return self.end_time - self.start_time

class ContainerStatus:
    def __init__(self,id):
        self.id = id
        self.delay = 0.0
        self.fetch = dict()
        self.fetch['stats'] = FetchStatus('stats')
        self.fetch['json'] = FetchStatus('json')

    def setDelay(self, delay):
        self.delay = delay

    def isOK(self):
        for qn,qs in self.fetch.items():
            if not (qs.state == FetchState.OK and qs.data ):
                return False
        return True

class PerfStatistic:
    def __init__(self):
        self.count = 0
        self.min = 0.0
        self.max = 0.0
        self.mean = 0.0
        self.var = 0.0

    def update(self, l):
        self.count = len(l)
        if self.count > 0:
            self.min = min(l)
            self.max = max(l)
            self.mean = statistics.mean(l)
        if self.count > 1:
            self.var = statistics.variance(l)

    def __str__(self):
        if self.count > 0:
            return "[count:{} min:{:.3f} max:{:.3f} mean:{:.3f} var:{:.3f}]".format(self.count,
                        self.min,
                        self.max,
                        self.mean,
                        self.var
                    )
        else:
            return "[count:0]"


class QueryPerfStatistics:

    def __init__(self):
        self.metrics = dict( ok = PerfStatistic(),
            err = PerfStatistic(),
            err_undef = 0,
            err_fail = 0,
            err_timeout = 0,
            err_notexists = 0,
        )

    def __str__(self):
        r = list()
        for k, v in self.metrics.items():
            if 'err_' in k:
                # only non-zero error counters
                if v > 0:
                    r.append( "{}:{}".format(k,str(v)))
            else:
                r.append( "{}:{}".format(k,str(v)))

        return ' '.join(r)

    def update(self, cont_statuses):
        self.metrics['ok'].update( [ x.get_time() for x in cont_statuses if  x.state == FetchState.OK ])
        self.metrics['err'].update( [ x.get_time() for x in cont_statuses if not x.state == FetchState.OK ])
        self.metrics['err_undef'] = len( [ x for x in cont_statuses if x.state == FetchState.UNDEF ])
        self.metrics['err_fail'] = len( [ x for x in cont_statuses if x.state == FetchState.FAIL ])
        self.metrics['err_timeout'] = len( [ x for x in cont_statuses if x.state == FetchState.FAIL_TIMEOUT ])
        self.metrics['err_notexist'] = len( [ x for x in cont_statuses if x.state == FetchState.FAIL_NOT_EXISTS ])

class DockerAsyncAPIClient:

    def __init__(self, connector_get, url_get):
        if connector_get is None or url_get is None:
           raise ValueError("Connector/url getter cannot be None")
        self.connector_get = connector_get
        self.url_get = url_get


    async def _fetch(self, what, session, cont_status, **kwargs):
        url = self.url_get( what, cont_status.id )
        cont_status.fetch[what].url = url
        cont_status.fetch[what].data = None
        try:
            await asyncio.sleep(cont_status.delay)
            log.debug( "START QUERY url:{}".format(url))
            cont_status.fetch[what].start_time = time.time()
            async with session.get(url, **kwargs) as resp:
                resp.raise_for_status()
                cont_status.fetch[what].data = await resp.json()
        except aiohttp.ServerTimeoutError as ste:
            cont_status.fetch[what].exception = 'ServerTimeoutError:{}'.format(str(ste))
            cont_status.fetch[what].state = FetchState.FAIL_TIMEOUT
        except aiohttp.ClientResponseError as cre:
            cont_status.fetch[what].exception = 'ClientResponseError:{}'.format(str(cre))
            cont_status.fetch[what].state = FetchState.FAIL_NOT_EXISTS
        except asyncio.TimeoutError as et:
            cont_status.fetch[what].exception = 'AsyncioTimeoutError:{}'.format(str(et))
            cont_status.fetch[what].state = FetchState.FAIL_TIMEOUT
        except Exception as e:
            cont_status.fetch[what].exception = 'GenericError:{}/{}'.format(str(e), type(e))
            cont_status.fetch[what].state = FetchState.FAIL
        else:
            cont_status.fetch[what].state = FetchState.OK

        cont_status.fetch[what].end_time = time.time()
        log.debug( "END QUERY cont_id:{} res:{} what:{}, start:{}, elapsed:{}".format(cont_status.id,
                    cont_status.fetch[what].state,
                    what,
                    cont_status.fetch[what].start_time,
                    cont_status.fetch[what].end_time - cont_status.fetch[what].start_time
        ))
        if not cont_status.fetch[what].exception is None:
            log.info( "Query failed: cont_id:{} res:{} what:{}, start:{}, elapsed:{}, ex:{}".format(cont_status.id,
                    cont_status.fetch[what].state,
                    what,
                    cont_status.fetch[what].start_time,
                    cont_status.fetch[what].end_time - cont_status.fetch[what].start_time,
                    cont_status.fetch[what].exception
        ))


    def addTask(self, session, container_id, tasks, res, delay, loop ):
        log.debug( "ADD TASKS FOR {} delay:{}".format(container_id, delay))
        res[container_id] = ContainerStatus( container_id )
        res[container_id].setDelay(delay)
        tasks.append( asyncio.ensure_future( self._fetch('stats', session, res[container_id], params={'stream': '0'} ),loop=loop))
        tasks.append( asyncio.ensure_future( self._fetch('json', session, res[container_id]), loop=loop))

    async def _multi_stats(self, containers: set, result: list, loop, query_interval=0.0):
        res = dict()
        tasks = list()
        query_sent_interval = query_interval/2.0
        query_wait_interval = (query_interval - query_sent_interval)*0.75
        step_delay = query_sent_interval/len(containers)
        step = 0
        base_tmout = step_delay/2.0
        async with aiohttp.ClientSession(loop=loop,
                                         connector=self.connector_get(loop),
                                         conn_timeout=base_tmout/2.0,
                                         read_timeout=query_wait_interval) as session:
            for container_id in containers:
                self.addTask(session, container_id, tasks, res, step*step_delay, loop )
                step = step + 1
            await asyncio.wait(tasks)
        for container_id in containers:
            if res[container_id].isOK():
                main_stats = res[container_id].fetch['stats'].data
                inspect_stats = res[container_id].fetch['json'].data
                result.append({'container_id': container_id, 'main_stats': main_stats, 'inspect_stats': inspect_stats})
        perfstats = dict(stats=QueryPerfStatistics(), json=QueryPerfStatistics())
        perfstats['stats'].update( [ x.fetch['stats'] for x in res.values() ] )
        perfstats['json'].update( [ x.fetch['json'] for x in res.values() ] )
        log.info("performace_stats:{} performance_json:{}".format(perfstats['stats'], perfstats['json']))

    def multi_stats(self, containers: set, query_interval=0.0) -> list:
        setLogLevel()
        start = time.time()
        result = list()
        loop = asyncio.new_event_loop()
        loop.run_until_complete(self._multi_stats(containers, result,loop, query_interval))
        loop = None
        log.info("query took: res:{} time:{:.2f}sec".format( len(result), time.time() - start))
        return result

class ExtendedAPIClient(docker.APIClient, DockerAsyncAPIClient):

    def __init__(self, base_url=None, version=None, timeout=DEFAULT_TIMEOUT_SECONDS, num_pools=DEFAULT_NUM_POOLS):
        docker.APIClient.__init__(self, base_url=base_url, version=version, timeout=timeout, num_pools=num_pools)
        DockerAsyncAPIClient.__init__(self, self.getConnector, self.getUrl)

    def getConnector(self,loop):
        async_connector = None
         # only tcp (non-ssl) and unix socket supported atm
        if 'localunixsocket' in self.base_url:
            async_connector = aiohttp.UnixConnector(self._custom_adapter.socket_path, loop = loop)
        elif 'localnpipe' in self.base_url:
            raise DockerException('Npipe connector is not available')
        else:
            async_connector = aiohttp.TCPConnector(loop=loop)
        return async_connector

    def getUrl(self, what, container_id):
        return self._url("/containers/{0}/{1}", container_id, what)
 
