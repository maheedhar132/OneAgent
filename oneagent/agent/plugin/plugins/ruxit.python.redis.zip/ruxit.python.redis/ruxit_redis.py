from ruxit.api.data import PluginMeasurement, PluginProperty, PluginStateMetric
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.exceptions import ConfigException, NothingToReportException, AuthException
from ruxit.api.snapshot import parse_port_bindings
import redis
from collections import namedtuple, defaultdict
import time
from ruxit.utils.docker_helper import DockerUtils
from docker.errors import DockerException
from ruxit.api.data import MEAttribute
import os

import logging

log = logging.getLogger(__name__)

QueryDesc = namedtuple('QueryDesc', ['is_per_second', 'max'])
BindingData = namedtuple('BindingData', ['host', 'port'])
CollectedMetric = namedtuple('CollectedMetric', ['value', 'is_per_second', 'dim'])


class RedisPlugin(BasePlugin):

    def initialize(self, **kwargs):
        try:
            config = kwargs['config']
            self.timeseries = kwargs['json_config']['metrics']
            self.associated_entity = kwargs['associated_entity']

            if 'auth_password' in config:
                self.password = config['auth_password']
            else:
                raise ConfigException("'Password' field is not present in configuration")
            self.cfg_file = config.get("cfg_file_location", "")
            if not self.cfg_file:
                self.cfg_file = "/usr/local/etc/redis/redis.conf"
            if not os.path.isabs(self.cfg_file):
                raise ConfigException("Path to config file must be absolute!")
            self.cfg_port = config.get("cfg_port", None)
            self.cfg_port = None if self.cfg_port == "" else self.cfg_port

            self.r = None

            entity = kwargs["associated_entity"]
            self.config_command = entity.properties.get("REDIS_CONFIG", "CONFIG")
            self.info_command = entity.properties.get("REDIS_INFO", "INFO")
            self.slowlog_command = entity.properties.get("REDIS_SLOWLOG", "SLOWLOG")

            self._process = self.associated_entity.processes[0]
            self.binding_data = self._find_redis_binding()

            self._read_config_file()
            self._connect()
            self.redis_metrics = {}
            self.redis_db_metrics = {}
            self._initialize_metrics()
            self.hit_ratio_old = {'keyspace_hits': None, 'keyspace_misses': None}
            self.hit_ratio = {'keyspace_hits': None, 'keyspace_misses': None}
        except DockerException:
            log.info("Redis plugin is unable to connect to docker socket. Docker setup is possibly not supported or pluginagent has not enough permission")
            raise AuthException("Unable to connect to Docker socket")

    @property
    def docker_mode(self):
        return self._is_redis_container(self.associated_entity)

    @property
    def process(self):
        return self._process

    def _find_redis_binding(self):
        port_bindings = parse_port_bindings(self.associated_entity)
        if len(port_bindings) > 0:
            port_to_use = port_bindings[0][1] if self.cfg_port is None else int(self.cfg_port)
            return BindingData(host=port_bindings[0][0], port=port_to_use)
        if self.docker_mode:
            port_to_use = self.process.properties["ListeningInternalPorts"] if self.cfg_port is None else self.cfg_port
            if len(port_to_use.split(" ")) > 1:
                raise ConfigException('Unable to detect Redis binding - multiple ports detected')
            return BindingData(host="127.0.0.1",
                               port=int(port_to_use))
        raise ConfigException('Unable to detect Redis binding')

    def _is_redis_container(self, associated_entity):
        for process in associated_entity.processes:
            if "DockerMount" in process.properties:
                self._process = process
                return True
        return False

    def _parse_config_line(self, line):
        line_parts = line.split(" ")
        if len(line_parts) < 3 and line_parts[0] != "rename-command":
            return
        if line_parts[1] == "CONFIG":
            self.config_command = " ".join(line_parts[2:]).strip()
        if line_parts[1] == "INFO":
            self.info_command = " ".join(line_parts[2:]).strip()
        if line_parts[1] == "SLOWLOG":
            self.slowlog_command = " ".join(line_parts[2:]).strip()

    def _read_config_file(self,):
        if self.docker_mode:
            conf_file = DockerUtils.file_wrapper(self.process.properties, self.cfg_file)
            with conf_file:
                for line in conf_file:
                    self._parse_config_line(line)
        else:
            if os.path.exists(self.cfg_file) and os.access(self.cfg_file, os.R_OK):
                with open(self.cfg_file) as conf_file:
                    for line in conf_file:
                        self._parse_config_line(line)

    def _connect_in_docker(self):
        process_data = self.process.properties
        self.cli_in_docker = DockerUtils.docker_process(process_data)
        self.cli_in_docker.run("redis-cli -p {port}".format(port=self.binding_data.port))
        if self.password:
            self.cli_in_docker.run("AUTH {p}".format(p=self.password))

    def _connect(self):
        try:
            if self.docker_mode:
                self._connect_in_docker()
                return
            self.r = redis.StrictRedis(host=self.binding_data.host,
                                       port=self.binding_data.port,
                                       password=self.password)
            self._get_redis_info()
        except redis.exceptions.ResponseError as e:
            if str(e) == "unknown command 'AUTH'":
                log.info('Authorization credentials were used with Sentinel endpoint...trying without password')
                try:
                    self.r = redis.StrictRedis(host=self.binding_data.host,
                                               port=self.binding_data.port)
                    self._get_redis_info()
                except redis.exceptions.ResponseError as e:
                    if str(e) == "NOAUTH Authentication required.":
                        raise ConfigException("Redis Sentinel does not support password protection")
                    else:
                        raise ConfigException(e.args) from e
                except redis.exceptions.ConnectionError as e:
                    raise ConfigException(e.args) from e
            else:
                raise ConfigException(e.args) from e

        except redis.exceptions.ConnectionError as e:
            raise ConfigException(e.args) from e

    def _initialize_metrics(self):
        redis_metrics = {}
        redis_db_metrics = {}

        try:
            for metric in self.timeseries:
                if 'statetimeseries' in metric:
                    continue
                query = metric['timeseries']['key']
                if metric['timeseries']['unit'] == 'PerSecond':
                    per_second = True
                else:
                    per_second = False
                timeseries_dim = metric['timeseries']['dimensions']
                max = metric.get('source',{}).get('max',None)
                if len(timeseries_dim) == 0:
                    redis_metrics[query] = QueryDesc(per_second, max)
                else:
                    redis_db_metrics[query] = QueryDesc(per_second, max)
        except KeyError:
            log.info(self, exc_info=1)

        self.redis_metrics = redis_metrics
        self.redis_db_metrics = redis_db_metrics

    def query(self, **kwargs):
        try:
            info = self._get_info_data()
            self._report_role(info)
            self._report_state(info)

            self.databases_no = int(self._get_redis_config().get('databases', 0))
            self.redis_collected_metrics = defaultdict(list)
            for query, query_desc in self.redis_metrics.items():
                self._get_redis_metric(query, query_desc, info)
            for query, query_desc in self.redis_db_metrics.items():
                self._get_redis_metric(query, query_desc, info, database_metric=True)

            self._calculate_and_report_memory_usage()
            self._calculate_and_report_hit_ratio()
            self._get_and_report_slowlog_len()
            self._report_collected_metrics()

        except (redis.exceptions.ResponseError, redis.exceptions.ConnectionError) as ex:
            raise ConfigException(ex.args) from ex

    def _get_info_data(self):
        time_start = time.time()
        info = self._get_redis_info()
        time_stop = time.time()

        self.results_builder.add_absolute_result(PluginMeasurement(
            key='responsiveness',
            value=round((time_stop - time_start) * 1000, 2)
        )
        )
        return info

    def _report_role(self, info):
        redis_mode = info.get('redis_mode', None)
        if redis_mode and redis_mode.lower() == 'sentinel':
            self._report_contributed_name('Redis Sentinel')
            raise NothingToReportException('Redis runs as sentinel')

        if redis_mode is None:
            raise NothingToReportException('Redis mode could not be detected')

        redis_role = info.get('role', None)
        redis_role is not None and self._report_contributed_name('Redis' + ' (' + redis_role + ')')

    def _report_state(self, info):
        try:
            if info.get('role', None) == 'slave':
                state = None
                link_status = info.get('master_link_status', None)
                sync_in_progress = info.get('master_sync_in_progress', None)
                if link_status == "up" and sync_in_progress == 0:
                    state = "Synchronized"
                elif link_status == "down":
                    if sync_in_progress == 0:
                        state = "Unsynchronized"
                    elif sync_in_progress == 1:
                        state = "Sync in progress"
                self.results_builder.add_absolute_result(PluginStateMetric(key='slave_state', value=state))
        except:
            log.info(self, exc_info=1)

    def _report_contributed_name(self, c_name):
        self.results_builder.add_property(PluginProperty(
            value=c_name,
            me_attribute=MEAttribute.CONTRIBUTED_NAME
        )
        )

    def _get_value(self, any_value):
        if any_value:
            return float(any_value)
        else:
            return None

    def _get_redis_metric(self, query:str, query_desc:QueryDesc, info, database_metric=False):
        try:
            if not database_metric:
                query_value = str(info.get(query,))
                float_value = self._get_value(query_value)
                if float_value:
                    if query_desc.max is not None and query_desc.max < float_value:
                        log.info(f'Value {query_value} is greater than {query_desc.max} for {query} metric')
                        float_value = query_desc.max
                    self.redis_collected_metrics[query].append(
                        CollectedMetric(float_value, query_desc.is_per_second, None))
                    if query in ['keyspace_hits', 'keyspace_misses']:
                        self.hit_ratio[query] = float_value
            else:
                for x in range(self.databases_no):
                    db_name = 'db' + str(x)
                    dim = {'database': db_name}
                    query_value = info.get(db_name, {}).get(query)
                    float_value = self._get_value(query_value)
                    if float_value:
                        self.redis_collected_metrics[query].append(
                            CollectedMetric(float_value, query_desc.is_per_second, dim))
        except:
            log.info(self, exc_info=1)

    def _calculate_and_report_memory_usage(self):
        if 'used_memory' not in self.redis_collected_metrics or 'maxmemory' not in self.redis_collected_metrics:
            log.info('Cannot calculate Redis memory usage as "used memory" or "maxmemory" data is not available')
            return
        used_memory = int(self.redis_collected_metrics['used_memory'][0].value)
        maxmemory = int(self.redis_collected_metrics['maxmemory'][0].value)
        if maxmemory != 0:
            self.results_builder.add_absolute_result(PluginMeasurement(
                key='maxmemory',
                value=maxmemory
            )
            )
            self.results_builder.add_absolute_result(PluginMeasurement(
                key='memory_usage',
                value=used_memory / maxmemory * 100
            )
            )

    def _calculate_and_report_hit_ratio(self):
        try:
            if self.hit_ratio_old['keyspace_hits'] is not None and self.hit_ratio_old['keyspace_misses'] is not None:
                hits = self.hit_ratio['keyspace_hits'] - self.hit_ratio_old['keyspace_hits']
                misses = self.hit_ratio['keyspace_misses'] - self.hit_ratio_old['keyspace_misses']
                if hits + misses > 0:
                    calculated_hit_ratio = hits / (hits + misses) * 100
                    self.results_builder.add_absolute_result(PluginMeasurement(
                        key='hit_ratio',
                        value=calculated_hit_ratio
                    )
                    )
        except KeyError:
            log.info(self, exc_info=1)

        self.hit_ratio_old['keyspace_hits'] = self.hit_ratio['keyspace_hits']
        self.hit_ratio_old['keyspace_misses'] = self.hit_ratio['keyspace_misses']

    def _get_and_report_slowlog_len(self):
        try:
            self.results_builder.add_relative_result(PluginMeasurement(
                key='slowlog_len',
                value=self._get_redis_slowlog_len()
            )
            )
        except:
            log.info(self, exc_info=1)

    def _report_collected_metrics(self):
        for query, metrics in self.redis_collected_metrics.items():
            for metric in metrics:
                if metric.is_per_second:
                    self.results_builder.add_per_second_result(PluginMeasurement(
                        key=query,
                        value=metric.value,
                        dimensions=metric.dim
                    )
                    )
                else:
                    self.results_builder.add_absolute_result(PluginMeasurement(
                        key=query,
                        value=metric.value,
                        dimensions=metric.dim
                    )
                    )

    def _get_redis_info(self):
        if self.docker_mode:
            got_info = self._parse_cli_output(self.cli_in_docker.run(self.info_command))
            return_dict = {}
            for line in got_info:
                line_splitted = line.split(":")
                if len(line_splitted) == 2:
                    return_dict[line_splitted[0]] = line_splitted[1]
            return return_dict

        if self.info_command != "INFO":
            info_b = self.r.execute_command(self.info_command)
            return self.r.response_callbacks['INFO'](info_b)
        else:
            return self.r.info()

    def _get_redis_config(self):
        if self.docker_mode:
            got_config = self._parse_cli_output(self.cli_in_docker.run(self.config_command + " GET * "))
            return_dict = {}
            key = ""
            value = ""
            for num, line in enumerate(got_config):
                if num % 2 == 0:
                    key = line
                else:
                    value = line
                    return_dict[key] = value
            return return_dict
        if self.config_command != "CONFIG":
            config_b = self.r.execute_command(self.config_command + ' GET *')
            return self.r.response_callbacks['CONFIG GET'](config_b)
        else:
            return self.r.config_get()

    def _get_redis_slowlog_len(self):
        if self.docker_mode:
            slowlog = self.cli_in_docker.run(self.slowlog_command + " LEN")
            got_slowlog = self._parse_cli_output(slowlog)
            return got_slowlog[0]
        if self.slowlog_command != "SLOWLOG":
            return self.r.execute_command(self.slowlog_command + ' LEN')
        else:
            return self.r.slowlog_len()

    """
    redis-cli returns output with unusual characters, removing them
    """

    def _parse_cli_output(self, output):
        return ''.join([i if ord(i) < 128 and ord(i) > 4 and ord(i) != 8 and ord(i) != 26 else '' for i in
                        output]).strip().splitlines()
