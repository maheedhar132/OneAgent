from ruxit.api.base_plugin import BasePlugin
from ruxit.api.snapshot import pgi_name
from ruxit.api.exceptions import ConfigException
from ruxit.api.selectors import ExplicitPgiSelector
from ruxit.api.data import PluginMeasurement
import requests
import json

import logging
log = logging.getLogger(__name__)

def is_docker_entry(entry):
    '''
    Checks whether a particular snapshot entry is running inside a docker container.
    '''
    for process in entry.processes:
        if process.properties.get('DockerMount', None) and process.process_name == 'php-fpm':
            return True
    return False


class PhpFpmPlugin(BasePlugin):

    _query_error = None

    def initialize(self, **kwargs):
        docker_pgs = self.find_all_process_groups(is_docker_entry)
        if len(docker_pgs) > 0:
            raise ConfigException('Dockerized PHP-FPM is not supported yet')

        self.data_fields_absolute = {'listen queue', 'listen queue len', 'active processes',
                                     'total processes', 'slow requests'}
        self.data_fields_relative = {'accepted conn'}

        config = kwargs['config']
        if 'status_uri' in config:
            if not config["status_uri"]:
                raise ConfigException("'Status page URI' field needs to be provided")
            self.status_uris = [s + "?json" for s in config["status_uri"].split()]
        else:
            raise ConfigException("'Status page URI' field is not present in configuration")

    def query(self, **kwargs):
        _pgis = self.find_all_process_groups(pgi_name('PHP-FPM'))

        reported = False
        for _pgi in _pgis:
            _pgi_id = _pgi.group_instance_id
            for _uri in self.status_uris:
                _status_page = self._read_status_page(_uri, _pgi_id)
                if _status_page is not None:
                    _stats = self._get_status_data(_status_page, _uri, _pgi_id)
                    if _stats is not None:
                        reported |= self._construct_timeseries(_stats, _pgi_id)

        self._check_for_errors(reported)

    def _read_status_page(self, _uri, _pgi_id):
        try:
            _status_response = requests.get(_uri, timeout=5, verify=False)
            return _status_response.content.decode()
        except requests.exceptions.Timeout:
            self._query_error = 'taking status timed out (PGI id {}, URI {}'.format(str(_pgi_id), _uri)
            return None
        except:
            self._query_error = 'PGI id {}: cannot read status page at {}'.format(str(_pgi_id), _uri)
            return None

    def _get_status_data(self, _status_json, _uri, _pgi_id):
        try:
            return json.loads(_status_json)
        except:
            self._query_error = "PGI id {}: cannot decode status page data at {}, data = '{}'"\
                .format(str(_pgi_id), _uri, _status_json)
            return None

    def _construct_timeseries(self, _stats, _pgi_id) -> bool:
        _dimension = {"pool": _stats["pool"]}
        try:
            for _df in self.data_fields_absolute:
                self.results_builder.add_absolute_result(PluginMeasurement(
                    key=_df.replace(' ', '_'), value=_stats[_df],
                    dimensions=_dimension, entity_selector=ExplicitPgiSelector(_pgi_id)))
            for _df in self.data_fields_relative:
                self.results_builder.add_relative_result(PluginMeasurement(
                    key=_df.replace(' ', '_'), value=_stats[_df],
                    dimensions=_dimension, entity_selector=ExplicitPgiSelector(_pgi_id)))
            return True
        except KeyError:
            self._query_error = 'Unable to get {0} data for pool {1}'.format(str(_df), str(_stats["pool"]))
            return False

    def _check_for_errors(self, _any_success: bool):
        if self._query_error is not None:
            log.info("[php-fpm plugin] " + self._query_error)
            _query_error = self._query_error
            self._query_error = None
            if not _any_success:
                raise ConfigException(_query_error)
