import sys
import os
import collections
import platform
from ruxit.api.data import PluginMeasurement, PluginProperty
from ruxit.api.base_plugin import BasePlugin

CpuUsage = collections.namedtuple("CpuUsage", ["user", "system", "idle", "total"])


class HeartBeatPlugin(BasePlugin):
    def initialize(self, **kwargs):
        self.last_cpu_times = CpuUsage(0, 0, 0, 0)

    def query(self, **kwargs):
        if sys.platform == 'win32':
            self._query_windows()
        else:
            self._query_linux()
        # self.results_builder.add_property(PluginProperty("ruxit.python.heartbeat.node_name", platform.node()))

    @staticmethod
    def _filetime_to_python_long(filetime):
        return (filetime.dwHighDateTime << 32) + filetime.dwLowDateTime

    def _report_get_cpu_usage(self, cpu_times):
        cpu_usage = CpuUsage(
            user=100.0 * ((cpu_times.user - self.last_cpu_times.user) / (cpu_times.total - self.last_cpu_times.total)),
            system=100.0 * ((cpu_times.system - self.last_cpu_times.system) / (cpu_times.total - self.last_cpu_times.total)),
            idle=100.0 * ((cpu_times.idle - self.last_cpu_times.idle) / (cpu_times.total - self.last_cpu_times.total)),
            total=cpu_times.total
        )
        first_run = self.last_cpu_times.total == 0
        self.last_cpu_times = cpu_times
        if not first_run:
            self.results_builder.add_absolute_result(PluginMeasurement(key='cpu_user', value=cpu_usage.user))
            self.results_builder.add_absolute_result(PluginMeasurement(key='cpu_system', value=cpu_usage.system))
            self.results_builder.add_absolute_result(PluginMeasurement(key='cpu_idle', value=cpu_usage.idle))

    def _query_windows(self):
        import ctypes
        import ctypes.wintypes

        ctypes.windll.kernel32.GetTickCount64.restype = ctypes.c_uint64
        tick = ctypes.windll.kernel32.GetTickCount64()
        uptime = tick / 1000
        self.results_builder.add_absolute_result(PluginMeasurement(key='uptime', value=uptime))

        _win_idletime = ctypes.wintypes.FILETIME()
        _win_kerneltime = ctypes.wintypes.FILETIME()
        _win_usertime = ctypes.wintypes.FILETIME()

        ctypes.windll.kernel32.GetSystemTimes(
            ctypes.byref(_win_idletime),
            ctypes.byref(_win_kerneltime),
            ctypes.byref(_win_usertime)
        )
        _idletime = self._filetime_to_python_long(_win_idletime)
        _kerneltime = self._filetime_to_python_long(_win_kerneltime)
        _usertime = self._filetime_to_python_long(_win_usertime)

        # kerneltime includes idletime
        total = _kerneltime + _usertime

        # HostMetricsImpl.cpp says this can happen
        if _kerneltime < _idletime:
            _kerneltime = self.last_cpu_times.system
        else:
            _kerneltime -= _idletime

        cpu_times = CpuUsage(
            user=_usertime,
            system=_kerneltime,
            idle=_idletime,
            total=total
        )

        self._report_get_cpu_usage(cpu_times)

    def _query_linux(self):
        with open('/proc/uptime', 'r') as f:
            uptime = float(f.readline().split()[0])
        self.results_builder.add_absolute_result(PluginMeasurement(key='uptime', value=uptime))
        # note: I am ignoring kernel 2.6.32.-279 idle time workaround present in native code
        CLOCK_TICKS = os.sysconf("SC_CLK_TCK")
        with open('/proc/stat', 'rb') as f:
            values = f.readline().split()
        fields = [float(x) / CLOCK_TICKS for x in values[1:]]
        total = sum(fields)
        # TODO: times and usage are not the same!
        cpu_times = CpuUsage(
            user=fields[0] + fields[1],
            system=fields[2],
            idle=fields[3],
            total=total
        )
        self._report_get_cpu_usage(cpu_times)
