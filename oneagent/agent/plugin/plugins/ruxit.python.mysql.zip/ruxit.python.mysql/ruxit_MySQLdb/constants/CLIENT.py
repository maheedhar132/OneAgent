# File is named this way because that's how it is in MySQLdb, and SQLAlchemy
# looks for it.

FOUND_ROWS = 2