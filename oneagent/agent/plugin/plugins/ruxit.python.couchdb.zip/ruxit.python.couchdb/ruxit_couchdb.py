from ruxit.api.data import PluginMeasurement
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.exceptions import ConfigException, AuthException
from ruxit.api.selectors import ListenPortSelector
import requests
import logging
from collections import defaultdict
from contextlib import suppress

log = logging.getLogger(__name__)


class CouchDBPlugin(BasePlugin):

    CURRENT_VALUES = [
        'auth_cache_hits', 'auth_cache_misses',
        'open_databases', 'open_os_files'
    ]

    STATS_SECTIONS = [
        'couchdb', 'httpd_request_methods', 'httpd_status_codes', 'httpd'
    ]

    def initialize(self, **kwargs):
        config = kwargs['config']
        self.process_types = kwargs['activation_context'].value.process_types

        if config['port'] == '':
            raise ConfigException("port is empty")
        self.port = config['port']
        self.auth = None
        if 'auth_user' in config and 'auth_password' in config:
            self.user = config['auth_user']
            self.password = config['auth_password']
        else:
            raise ConfigException("user or password is empty")

        self.statistics_url = self._construct_url()
        self.auth = self._get_auth()

    def _construct_url(self):
        return 'http://localhost:{port}/_stats?range=60'.format(port=self.port)

    def _get_auth(self):
        if not self.user:
            return None
        else:
            return self.user, self.password

    def _createpm(self, *args, **kwargs):
        return PluginMeasurement(*args, entity_selector=ListenPortSelector(self.port, self.process_types), **kwargs)

    def query(self, **kwargs):
        try:
            response = requests.get(self.statistics_url,
                                    auth=self.auth,
                                    verify=False,
                                    timeout=5)
            if response.status_code != 200:
                if response.status_code == 401:
                    raise AuthException
                raise ConfigException('Error ' + str(response.status_code) +
                                      ' while receiving CouchDB \_stats data')
            couchdb_stats = response.json()
        except requests.exceptions.ConnectionError as ex:
            raise ConfigException('Unable to connect to CouchDB') from ex

        for stats_section in self.STATS_SECTIONS:
            stats = couchdb_stats.get(stats_section, None)
            if stats is None:
                log.info(str(stats) + ' not available')
                continue

            if stats_section == 'httpd_status_codes':
                self._report_http_rsp_codes(stats)
            else:
                self._report_stats(stats)

        self._report_special_metrics(couchdb_stats)

    def _report_http_rsp_codes(self, stats):
        http_rsp_buckets = defaultdict(int)
        for key, value in stats.items():
            current = value['mean']
            if current is not None:
                http_rsp_buckets['http_' + str(key[0]) + 'xx'] += current

        for http_rsp, value in http_rsp_buckets.items():
            self.results_builder.add_absolute_result(self._createpm(
                key=http_rsp,
                value=value,
                )
            )

    def _report_stats(self, stats):
        for stat_name, value in stats.items():
            value_to_send = value['current'] if stat_name in self.CURRENT_VALUES else value['mean']
            value_to_send is not None and self.results_builder.add_absolute_result(self._createpm(
                key=stat_name,
                value=value_to_send,
                )
            )

    def _report_special_metrics(self, couchdb_stats):
        with suppress(KeyError):
            value_to_send = couchdb_stats['couchdb']['request_time']['max']
            value_to_send is not None and self.results_builder.add_absolute_result(self._createpm(
                key='request_time_max',
                value=value_to_send,
                )
            )