"""
OneAgent MongoDB plugin
=======================

Gathers MongoDB stats using two MongoDB commands:

* dbStats -  https://docs.mongodb.com/manual/reference/command/dbStats/
* serverStatus - https://docs.mongodb.com/manual/reference/command/serverStatus/

Running the plugin requires specifying:

* user credentials - *clusterMonitor* role is required. If authorization is disabled on MongoDB then leave *user* and *password* fields empty
* port - access to the MongoDB via localhost interface is required

This is a singleton type plugin - one instance will be created even if multiple MongoDB process
groups instances are detected.

"""

import pymongo
from ruxit.api.exceptions import AuthException, ConfigException
from ruxit.api.data import PluginMeasurement
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.selectors import ListenPortSelector
import re
import ssl
from collections import namedtuple
from ruxit.api.snapshot import parse_port_bindings
from urllib.parse import quote

import logging
log = logging.getLogger(__name__)

QueryDesc = namedtuple("QueryDesc", ["timeseries_key", "per_second_result_flag"])
"""
Namedtuple used for storing informations about timeseries metric, including corresponding timeseries key and information about metric type.
"""


class MongodbPlugin(BasePlugin):
    """
    MongoDB plugin class. This plugin is stateful, however, the state is limited to
    processing of JSON and received configuration together with maintaining database connection.
    """

    def initialize(self, **kwargs):
        self.mongodb_client = None
        self.time_series = None
        self.process_types = None
        self.process_snapshot = None
        self.port = None
        self.user = None
        self.password = None
        self.server_status_metrics = {}
        self.db_stats_metrics = {}
        self.regex_pattern = "\[\'([^\']*)\'\]"
        self.mongodb_auth_error_codes = [13, 18]
        self.connection_timeout = 15000 #millisecond

        config = kwargs['config']
        self.time_series = kwargs['json_config']['metrics']
        self.process_types = kwargs['activation_context'].value.process_types
        self.process_snapshot = kwargs['process_snapshot']

        if not config['port']:
            raise ConfigException("port is empty")
        self.port = config['port']
        if 'auth_user' in config and 'auth_password' in config:
            self.user = config['auth_user']
            self.password = config['auth_password']
        else:
            raise ConfigException("user or password is empty")
        self.auth_db = config.get('auth_db', False)
        self.tlsInsecure = config.get('tls_insecure', False)

        self.create_client(self._create_uri())
        self.initialize_metrics()

    def query(self, **kwargs):
        self.get_server_metrics()
        self.get_database_metrics()

    def create_client(self, uri):
        try:
            self.mongodb_client = pymongo.MongoClient(uri, tls=True, tlsInsecure=self.tlsInsecure, serverSelectionTimeoutMS=self.connection_timeout)
            self.mongodb_client.database_names()
            log.info("Connected to mongodb[SSL]")
        except pymongo.errors.ConnectionFailure:
            try:
                self.mongodb_client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=self.connection_timeout)
                self.mongodb_client.database_names()
                log.info("Connected to mongodb")
            except pymongo.errors.OperationFailure as e:
                self.mongodb_client.close()
                del self.mongodb_client
                self.filter_auth_exceptions(e)
            except pymongo.errors.PyMongoError as e:
                self.mongodb_client.close()
                del self.mongodb_client
                raise ConfigException(e)
        except pymongo.errors.OperationFailure as e:
            self.mongodb_client.close()
            del self.mongodb_client
            self.filter_auth_exceptions(e)
        except pymongo.errors.PyMongoError as e:
            self.mongodb_client.close()
            del self.mongodb_client
            raise ConfigException(e)

    def filter_auth_exceptions(self, exception):
        if exception.code in self.mongodb_auth_error_codes:
            raise AuthException from exception
        else:
            raise ConfigException(exception)

    def initialize_metrics(self):
        """
        On plugin creation corresponding plugin.json file is processed in order to extract
        statistics that are related to server status and particular database.
        """
        server_status_metrics = {}
        db_stats_metrics = {}

        try:
            for metric in self.time_series:
                query = metric['source']['query']
                time_series_key = metric['timeseries']['key']
                per_second_result_flag = metric.get('source', {}).get('persecond', False)
                query_start_index = query.find('[')

                if query.startswith('server_status'):
                    server_status_metrics[query[query_start_index:]] = QueryDesc(time_series_key, per_second_result_flag)
                elif query.startswith('db_stats'):
                    db_stats_metrics[query[query_start_index:]] = QueryDesc(time_series_key, per_second_result_flag)
        except KeyError:
            log.info(self, exc_info=1)
        self.server_status_metrics = server_status_metrics
        self.db_stats_metrics = db_stats_metrics

    def _create_pm(self, *args, **kwargs):
        return PluginMeasurement(*args, entity_selector=ListenPortSelector(self.port, self.process_types), **kwargs)

    def _add_result(self, query_desc, value, dim=None):
        if value is not None:
            if query_desc.per_second_result_flag == 1:
                self.results_builder.add_per_second_result(self._create_pm(
                    key=query_desc.timeseries_key,
                    value=value,
                    dimensions=dim)
                    )
            else:
                self.results_builder.add_absolute_result(self._create_pm(
                    key=query_desc.timeseries_key,
                    value=value,
                    dimensions=dim)
                    )
        else:
            log.info('Metric ' + query_desc.timeseries_key + ' is not available')

    def _create_uri(self):
        for ps_entry in self.process_snapshot.entries:
            if ps_entry.process_type == 21:
                port_bindings = parse_port_bindings(ps_entry)
                for binding in port_bindings:
                    if str(binding[1]) == self.port:
                        return self._url(binding[0])

        log.info('PortBindings data: %s', port_bindings)
        raise ConfigException('Unable to detect MongoDB binding')

    def _url(self, ip):
        if not self.user or not self.password:
            url = 'mongodb://{address}:{port}'.format(address=ip, port=self.port)
        else:
            url = 'mongodb://{user}:{pwd}@{address}:{port}'.format(user=quote(self.user), pwd=quote(self.password), address=ip, port=self.port)
        if self.auth_db:
            url = '{mongo_url}/?authSource={auth_db}'.format(mongo_url=url, auth_db=self.auth_db)
        return url

    def get_server_metrics(self):
        """
        Collect MongoDB server level metrics and sends results.
        """
        server_status = self.mongodb_client.db.command("serverStatus")

        for query, query_desc in self.server_status_metrics.items():
            indices = re.findall(self.regex_pattern, query)
            value = self.get_value_of_indices_chain(indices, server_status)
            self._add_result(query_desc, value)

    def get_database_metrics(self):
        """
        Iterates over a list of database received in main query, collects and sends database level metrics.
        """
        database_names = self.mongodb_client.database_names()
        for database in database_names:
            db_stats = self.mongodb_client[database].command('dbstats')

            dim = {'database': database}

            for query, query_desc in self.db_stats_metrics.items():
                indices = re.findall(self.regex_pattern, query)
                value = self.get_value_of_indices_chain(indices, db_stats)
                self._add_result(query_desc, value, dim)

    @staticmethod
    def get_value_of_indices_chain(indices, dictionary):
        for index in indices:
            if index not in dictionary:
                return None
            dictionary = dictionary[index]
        return dictionary
