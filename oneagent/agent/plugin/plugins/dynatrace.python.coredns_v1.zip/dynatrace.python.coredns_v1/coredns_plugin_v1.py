"""
OneAgent CoreDNS plugin
=======================

Collects metrics regarding CoreDNS using its Prometheus metrics endpoint that is usually configured to be
on localhost:9153 but can be changed using Corefile.

Plugin tries to automatically detect the endpoint, checking for an existing Corefile and looking for the appropriate
entry there but it can be also configured to connect to the endpoint specified on the plugin configuration screen.
If the methods specified above fail, CoreDNS plugin falls back to the default endpoint location - localhost:9153.
Please note that the /metrics suffix is not needed when providing the endpoint.

Plugin gathers mostly data about the CoreDNS instance, extending it with the most important Go-related metrics.
Process-related metrics, though possible to gather, are not gathered by the plugin as these are already available
on the Process screen, delivered by OneAgent.

"""
import re
from collections import defaultdict
from copy import deepcopy
from itertools import chain
from typing import Dict, List, Optional, Tuple

from prometheus_client.metrics_core import Metric as PrometheusMetric
from requests.exceptions import ConnectionError
from ruxit.api.base_plugin import BasePlugin, ProcessGroupInstance
from ruxit.api.data import MEAttribute
from ruxit.api.exceptions import ConfigException

import metrics_transformation_v1 as mt
import prometheus_handler_v1 as ph
import reported_metrics_v1 as reported_metrics
from metrics_transformation_v1 import Metric


class CoreDNSPlugin(BasePlugin):
    DIMENSIONS_TO_EXTRACT_PER_METRIC = {
        "dns_response_rcode_count_total": ["rcode"]
    }

    def __init__(self, **kwargs):
        self.endpoint = None
        self.coredns_version = None
        super().__init__(**kwargs)

    def initialize(self, **kwargs):
        self.initialize_endpoint()

    def find_coredns_pgi(self) -> Optional[ProcessGroupInstance]:
        pgi = self.get_monitored_entities()[0]
        coredns_pgi = pgi.snapshot[0]
        if len(coredns_pgi.processes) != 1:
            self.logger.error("Expected a single CoreDNS process")
            return None
        return coredns_pgi

    def get_prometheus_endpoint(self, working_dir: str, cmd_line: str) -> str:
        endpoint_from_config = ph.parse_prometheus_endpoint_from_config(self.config)
        if endpoint_from_config:
            return endpoint_from_config

        corefile_path = ph.autodetect_corefile_path(working_dir, cmd_line)
        return ph.autodetect_prometheus_endpoint(corefile_path)

    def initialize_endpoint(self) -> None:
        pgi = self.find_coredns_pgi()
        if pgi is None:
            self.logger.error("Could not initialize endpoint - PGI not found")
            return None
        process = pgi.processes[0]
        cmd_line = ""
        if "CmdLine" in process.properties:
            cmd_line = process.properties["CmdLine"]
        self.endpoint = self.get_prometheus_endpoint(process.properties["WorkDir"], cmd_line)

    def collect_metrics_from_endpoint(self, endpoint: str) -> List[PrometheusMetric]:
        metrics = ph.get_metric_families(endpoint)
        metrics = ph.filter_metric_families(metrics, reported_metrics.ALL_METRICS)
        # collect all metrics here so that connection doesn't have to be opened for the whole time
        return [metric for metric in metrics]

    def collect_metrics(self) -> Optional[List[PrometheusMetric]]:
        if self.endpoint:
            try:
                return self.collect_metrics_from_endpoint(self.endpoint)
            except ConnectionError as ex:
                raise ConfigException(f"Connection to the endpoint '{self.endpoint}' failed. Please try specifying the "
                                      f"address in settings or verifying the already specified one.") from ex
        else:
            raise ConfigException("No endpoint detected nor specified. Please try specifying the address in settings. "
                                  "Are you sure CoreDNS is running with 'metrics' plugin?")

    def apply_dimension_extraction_where_needed(self, metrics: List[Metric], dimensions_to_extract_per_metric: Dict[str, List[str]] = DIMENSIONS_TO_EXTRACT_PER_METRIC) -> List[Metric]:
        """
        Extract values of specified dimensions from chosen metrics and place them in the metric name.
        Can prove helpful when in need of metric keys that indicate what is the value of one of their dimensions, for
        example when defining charts. Metric names are built by appending _DIMENSIONNAME_DIMENSIONVALUE to the original
        name. Should be used only when dimension values are known earlier.
        Example:
        For a metric family with two metrics:
        - Metric(name='X', dimensions={'d1': '5', 'd2': 'a'}, value=1)
        - Metric(name='X', dimensions={'d1': '8', 'd2': 'a'}, value=2)
        It returns:
        - Metric(name='X_d1_5', dimensions={'d2': 'a'}, value=1)
        - Metric(name='X_d1_8', dimensions={'d2': 'a'}, value=2)
        :param metrics: All metrics from all metric families in a flat list.
        :param dimensions_to_extract_per_metric: Dict of list of dimension names for each name of transformed family
        :return: Metrics with dimension extraction applied.
        """
        new_metrics = defaultdict(list)
        for metric in metrics:
            dim_names = dimensions_to_extract_per_metric.get(metric.name)
            new_metrics[metric.name].append(metric)
            if dim_names is None:
                continue

            new_name = ""
            new_dimensions = deepcopy(metric.dimensions)
            for dimension in dim_names:
                dimension_value = metric.dimensions.get(dimension)
                if dimension_value is None:
                    continue

                del new_dimensions[dimension]
                clean_dimension_value = re.sub(r'[^\w]', '_', dimension_value)
                new_name = f"{new_name}_{dimension}_{clean_dimension_value}"
            if new_name != "":
                new_metrics[metric.name].append(Metric(metric.type, metric.name + new_name, metric.value, new_dimensions))
        return list(chain.from_iterable(value for value in new_metrics.values()))

    def get_coredns_version(self, metrics: List[Metric]) -> Optional[Tuple[int, int, int]]:
        for metric in metrics:
            if metric.name == "build_info":
                try:
                    version = metric.dimensions["version"]
                except KeyError as e:
                    self.logger.error("Invalid build_info. Exception raised:\n" + str(e))
                    return
                components = version.split('.')
                try:
                    major, minor, patch = tuple(components)
                    return int(major), int(minor), int(patch)
                except ValueError as e:
                    self.logger.error(f"Invalid CoreDNS version: {version}. Exception raised:\n" + str(e))
                    return
        self.logger.error("CoreDNS version not found.")

    def fix_incompatibilities_in_metrics(self, metrics: List[Metric]) -> List[Metric]:
        """
        Modify the collected metrics to fulfil the assumptions regarding naming and dimensions.
        If a metric has 3 dimensions defined in plugin.json, the plugin cannot send a metric with only 2 of them,
        even if CoreDNS didn't provide the missing one. In such a case, some dummy (default) value must be placed.
        :param metrics: List of collected and transformed metrics
        :return: List of metrics with their potential incompatibilities solved.
        """
        if self.coredns_version >= (1, 6, 9):
            return metrics  # nothing to be done

        new_metrics = deepcopy(metrics)
        if self.coredns_version < (1, 6, 8):
            for metric in new_metrics:
                if metric.name == "dns_request_duration_seconds_sum":
                    metric.dimensions["type"] = '*'
                    break
        if self.coredns_version < (1, 1, 3):
            for metric in new_metrics:
                if metric.name.startswith("cache"):
                    metric.dimensions["server"] = '*'
        if self.coredns_version < (1, 1, 2):
            for metric in new_metrics:
                if metric.name.startswith("dns_request") or metric.name.startswith("dns_response"):
                    metric.dimensions["server"] = '*'
        return new_metrics

    def report_build_info(self, metric: Metric, pgi_id) -> None:
        try:
            version = metric.dimensions["version"]
            revision = metric.dimensions["revision"]
            go_version = metric.dimensions["goversion"]
        except KeyError as e:
            self.logger.error("Invalid build_info. Exception thrown:\n" + str(e))
            return

        self.results_builder.report_property(key="Version", value=version, me_attribute=MEAttribute.CUSTOM_PG_METADATA,
                                             entity_id=pgi_id)
        self.results_builder.report_property(key="Revision", value=revision,
                                             me_attribute=MEAttribute.CUSTOM_PG_METADATA, entity_id=pgi_id)
        self.results_builder.report_property(key="Go version", value=go_version,
                                             me_attribute=MEAttribute.CUSTOM_PG_METADATA, entity_id=pgi_id)

    def report_gauge(self, metric: Metric, pgi_id) -> None:
        self.results_builder.absolute(key=metric.name, value=metric.value, dimensions=metric.dimensions,
                                      entity_id=pgi_id)

    def report_counter(self, metric: Metric, pgi_id) -> None:
        self.results_builder.relative(key=metric.name, value=metric.value, dimensions=metric.dimensions,
                                      entity_id=pgi_id)

    def query(self, **kwargs):
        pgi = self.find_coredns_pgi()
        if pgi is None:
            return None
        pgi_id = pgi.group_instance_id

        metrics = self.collect_metrics()
        metrics = mt.transform_metrics(metrics, self.logger)
        metrics = self.apply_dimension_extraction_where_needed(metrics)

        if self.coredns_version is None:
            self.coredns_version = self.get_coredns_version(metrics)
        if self.coredns_version is not None:
            metrics = self.fix_incompatibilities_in_metrics(metrics)

        for metric in metrics:
            if metric.name == "build_info":
                self.report_build_info(metric, pgi_id)
            else:
                if metric.type == "gauge":
                    self.report_gauge(metric, pgi_id)
                else:  # it's either counter or _sum metric from summary/histogram (which acts like a counter)
                    self.report_counter(metric, pgi_id)
