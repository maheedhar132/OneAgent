from collections import namedtuple
from logging import Logger
from typing import List, Optional

from prometheus_client.metrics_core import Metric as PrometheusMetric

import prometheus_handler_v1 as ph

# transformed metric, to be used eventually by OneAgent
Metric = namedtuple("Metric", ["type", "name", "value", "dimensions"])


def transform_counter_or_gauge(metric: PrometheusMetric, logger: Logger) -> Optional[List[Metric]]:
    """
    Simply retrieve values from all samples in a metric
    :param metric: Prometheus counter or gauge
    :param logger: Logger
    :return: List of one or more (depending on samples count) OneAgent-compatible metrics, or None if error occurred
    """
    type = metric.type
    if len(metric.samples) > 1:
        metrics = []
        for sample in metric.samples:
            name = ph.remove_category_prefix(sample.name)
            metrics += [Metric(type, name, sample.value, sample.labels)]
        return metrics
    elif len(metric.samples) == 1:
        sample = metric.samples[0]
        name = ph.remove_category_prefix(sample.name)
        return [Metric(type, name, sample.value, sample.labels)]
    else:
        logger.error(f"No samples available in {metric.name} {type}")


def transform_histogram_or_summary(metric: PrometheusMetric, logger: Logger) -> Optional[List[Metric]]:
    """
    Retrieve sum from a histogram or a summary (which is similar to histogram), disregarding buckets and count
    :param metric: Prometheus histogram or summary
    :param logger: Logger
    :return: List of OneAgent-compatible metrics, or None if error occurred
    """
    type = metric.type
    if len(metric.samples) >= 3:  # at least one observation sample + sum and count
        for sample in reversed(metric.samples):  # sum should be on len - 2 position
            if sample.name.endswith("_sum"):
                name = ph.remove_category_prefix(sample.name)
                return [Metric(type, name, sample.value, sample.labels)]
    else:
        logger.error(f"Invalid number of samples in {metric.name} {type}: {len(metric.samples)}")


def transform_metrics(metrics: List[PrometheusMetric], logger: Logger) -> Optional[List[Metric]]:
    """
    Transform Prometheus metrics into OneAgent-compatible metrics
    :param metrics: Generator of Prometheus metrics
    :param logger: Logger
    :return: List of OneAgent-compatible metrics or None, if error occurred
    """
    transformed_metrics = []
    for metric in metrics:
        try:
            if metric.type == "counter" or metric.type == "gauge":
                transformed_metrics += transform_counter_or_gauge(metric, logger)
            elif metric.type == "histogram" or metric.type == "summary":
                transformed_metrics += transform_histogram_or_summary(metric, logger)
            else:
                logger.error("Unknown metric type: " + metric.type)
        except TypeError as error:
            logger.error("One of transformers encountered an error, probably already logged that: " + str(error))
    return transformed_metrics
