# metrics specified below are the ones that are saved during gathering of metrics from the endpoint
# note however that these metrics don't have to be sent to the server in that form, transformations may occur
# for the list of metrics that are actually sent, see "metrics" in plugin.json

COREDNS_METRICS = [
    "build_info",
    "cache_hits",
    "cache_misses",
    "cache_size",
    "dns_request_count",
    "dns_request_duration_seconds",
    "dns_request_size_bytes",
    "dns_request_type_count",
    "dns_response_rcode_count",
    "dns_response_size_bytes",
    "forward_max_concurrent_reject_count",
    "forward_request_count",
    "forward_request_duration_seconds",
    "forward_response_rcode_count",
    "health_request_duration_seconds",
    "panic_count"
]

GO_METRICS = [
    "gc_duration_seconds",
    "goroutines",
    "memstats_buck_hash_sys_bytes",
    "memstats_frees",
    "memstats_gc_sys_bytes",
    "memstats_heap_alloc_bytes",
    "memstats_heap_idle_bytes",
    "memstats_heap_inuse_bytes",
    "memstats_heap_objects",
    "memstats_heap_released_bytes",
    "memstats_heap_sys_bytes",
    "memstats_lookups",
    "memstats_mallocs",
    "memstats_mcache_inuse_bytes",
    "memstats_mcache_sys_bytes",
    "memstats_mspan_inuse_bytes",
    "memstats_mspan_sys_bytes",
    "memstats_next_gc_bytes",
    "memstats_other_sys_bytes",
    "memstats_stack_inuse_bytes",
    "memstats_stack_sys_bytes",
    "memstats_sys_bytes",
    "threads"
]

PROCESS_METRICS = [
]

ALL_METRICS = {
    "coredns": COREDNS_METRICS,
    "go": GO_METRICS,
    "process": PROCESS_METRICS
}
