import os
import re
from typing import Dict, Generator, List, Optional

import requests
from prometheus_client import parser
from prometheus_client.metrics_core import Metric
from ruxit.api.exceptions import ConfigException


def parse_prometheus_endpoint_from_config(config: Dict[str, str]) -> Optional[str]:
    """
    Try to obtain the endpoint from plugin config.
    Makes sure that endpoint format is appropriate and when it's not, fixes it where possible.
    Users should ideally enter IP:PORT (and minimally :PORT) but if they include http:// or /metrics, it will be fixed.
    If the user entered some endpoint in settings but it is unfixable, ConfigException is raised to inform about that.
    :param config: Result of self.config in plugin class
    :raises: ConfigException
    :return: Endpoint in the proper format, or an empty string if endpoint wasn't specified
    """
    endpoint_from_config = config["prometheus_endpoint"]
    if endpoint_from_config:
        result = re.match("(?:https?://)?([^/]+)?(:[0-9]+)(?:/.*)?", endpoint_from_config)
        if result is not None and result.group(2):
            if result.group(1):
                return result.group(1) + result.group(2)
            else:
                return "localhost" + result.group(2)
        else:
            raise ConfigException(f"Specified endpoint '{endpoint_from_config}' is invalid. It must contain at least "
                                  f"port number preceded by ':'.")
    else:
        return ""


def autodetect_corefile_path(working_dir: str, cmd_line: str) -> str:
    """
    Autodetect path of the Corefile based on how coredns was started.
    If the path couldn't be established, return default path (Corefile situated in working directory).
    Unsupported cases of detection:
    - more than one space in a row inside quoted path, e.g. (in cmd_line) -conf 'C:\\Program Data\\Core   DNS\\Corefile'
    :param working_dir: Working directory of coredns process
    :param cmd_line: Cmd line arguments of coredns process
    :return: Absolute path to the Corefile
    """
    DEFAULT_PATH = os.path.join(working_dir, "Corefile")

    if "-conf" in cmd_line:
        cmd_line_split = [sub for sub in cmd_line.split(' ') if sub]
        path_index = cmd_line_split.index("-conf") + 1
        if path_index == len(cmd_line_split):
            return DEFAULT_PATH  # -conf without value
        corefile_path = cmd_line_split[path_index]
        if corefile_path[0] == '\'' or corefile_path[0] == '"':
            sep = corefile_path[0]
            continuation_index = path_index + 1
            while corefile_path[-1] != sep and continuation_index < len(cmd_line_split):
                corefile_path += ' ' + cmd_line_split[continuation_index]
                continuation_index += 1
            if corefile_path[-1] != sep:
                return DEFAULT_PATH  # something didn't work out
            corefile_path = corefile_path[1:-1]  # remove separators
        if os.path.isabs(corefile_path):
            return corefile_path
        else:
            return os.path.join(working_dir, corefile_path)
    else:
        return DEFAULT_PATH


def get_prometheus_endpoint_from_corefile_content(corefile_content, default_ip: str) -> str:
    """
    Get endpoint setting from a Corefile.
    Looks for the line with configuration for 'metrics' plugin (starting with "prometheus") and gets the address from
    there. If configuration is ill-formed (which should cause problems either way on CoreDNS side) or 'metrics' plugin
    is inactive, returns an empty string.
    :param corefile_content: Content of the read Corefile
    :param default_ip: IP to use if only the port is specified
    :return: Address of the endpoint or an empty string if problems occurred
    """
    for line in corefile_content:
        if "prometheus" in line:
            line_split = line.split("prometheus", 1)
            if len(line_split) == 2:
                endpoint = line_split[1].strip()
                if endpoint.startswith(":"):
                    endpoint = default_ip + endpoint
                return endpoint
            else:
                return ""
    return ""


def autodetect_prometheus_endpoint(corefile_path: str) -> str:
    """
    Autodetect endpoint on which CoreDNS exposes its metrics.
    :param corefile_path: Path to the Corefile
    :return: Endpoint (IP:port) or empty string, if the endpoint couldn't be detected
    """
    DEFAULT_ENDPOINT = "localhost:9153"

    if not corefile_path or not os.path.exists(corefile_path):
        return DEFAULT_ENDPOINT
    with open(corefile_path, "r") as file:
        return get_prometheus_endpoint_from_corefile_content(file, "localhost")


def get_metric_families(endpoint: str) -> Generator[Metric, None, None]:
    response = requests.get("http://" + endpoint + "/metrics", stream=True)
    input_gen = response.iter_lines(chunk_size=10*1024, decode_unicode=True)

    for metric_family in parser.text_fd_to_metric_families(input_gen):
        yield metric_family


def remove_category_prefix(metric_family_name: str) -> str:
    index = metric_family_name.find("_") + 1
    return metric_family_name[index:]


def filter_metric_families(metric_families: Generator[Metric, None, None], reported_metric_families: Dict[str, List[str]]) -> Generator[Metric, None, None]:
    for metric_family in metric_families:
        for category_name in reported_metric_families.keys():
            if metric_family.name.startswith(category_name + "_"):
                metric_name = remove_category_prefix(metric_family.name)
                if metric_name in reported_metric_families[category_name]:
                    yield metric_family
                break
