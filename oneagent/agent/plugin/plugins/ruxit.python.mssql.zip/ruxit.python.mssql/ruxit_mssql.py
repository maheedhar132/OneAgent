"""
OneAgent MSSQL plugin
=====================

Gathers MSSQL stats.
The full description of stats is described at https://msdn.microsoft.com/en-us/en-en/library/ms190382(v=sql.110).aspx

MSSQL collect SQL server performance counters specified in JSON configuration using pywin32 which is a set of extension
modules that provides access to Windows API functions.

Plugin requires no configuration, database instance name is detected automatically from process snapshot.
"""

import collections
import sys

from ruxit.api.data import PluginMeasurement, PluginProperty
from ruxit.api.base_plugin import BasePlugin
import logging
if sys.platform == "win32":
    import win32pdhquery, win32pdhutil, win32pdh

log = logging.getLogger(__name__)

CounterDesc = collections.namedtuple("CounterDesc", ["path", "handle", "timeseriesKey"])
"""
Namedtuple that is used for storing details about particular performance counter: whole path including object and metric name,
handle to counter and corresponding timeseries key.
"""

class MsSqlPlugin(BasePlugin):
    """
    MSSQL plugin class. This plugin is stateful - initialize and close methods are defined
    in order to maintain one PDH query for the lifetime of the plugin.
    """
    def initialize(self, **kwargs):
        """
        Plugin initialization.
        This method includes opening PDH query, getting MSSQL instance name from snapshot and
        parsing plugin.json file in order to add all counters to query.
        """
        if sys.platform != "win32":
            return
        self.entity = kwargs["associated_entity"]
        self.timeseries = kwargs["json_config"]["metrics"]
        self.q = 0
        self.init_query()

    def init_query(self):
        self.counters = []
        if self.q:
            win32pdh.CloseQuery(self.q)
        self.q = win32pdh.OpenQuery()
        self.prefix = self.get_objectname_prefix()
        log.info('MSSQL prefix: ' + str(self.prefix))
        self.add_counters()

    def add_counters(self):
        """
        Parses timeseries defined in plugin.json one by one and adds particular counters to query
        """
        for metric in self.timeseries:
            path = metric['source']['query']
            timeseriesKey = metric['timeseries']['key']
            counter_path = '\\{prefix}:{pth}'.format(prefix=self.prefix, pth=path)
            try:
                counter_handle = win32pdh.AddEnglishCounter(self.q, counter_path)
                self.counters.append(CounterDesc(counter_path, counter_handle, timeseriesKey))
            except:
                log.info(self, exc_info=1)
                log.info('MSSQL counter_path: ' + str(counter_path))

    def get_objectname_prefix(self):
        """
        Returns MSSQL performance counter object prefix depending on instance name provided in process snapshot.
        """
        instance_name = self.entity.properties['mssql_instance_name']
        if instance_name.upper() == 'MSSQLSERVER':
            return 'SQLServer'
        else:
            return 'MSSQL${instance_name}'.format(instance_name=instance_name)

    def query(self, **kwargs):
        """
        Performs collecting PDH data and sends results if valid.
        """
        if sys.platform != "win32":
            return
        if len(self.counters) == 0:
            log.info('No perfmon counters defined - retrying query and counters initialization')
            self.init_query()
        try:
            win32pdh.CollectQueryData(self.q)
        except:
            log.info(self, exc_info=1)

        for counter in self.counters:
            try:
                value = win32pdh.GetFormattedCounterValue(counter.handle, win32pdh.PDH_FMT_DOUBLE)
                if value[1] != -1:
                    self.results_builder.add_absolute_result(PluginMeasurement(
                        key=counter.timeseriesKey,
                        value=value[1]
                    ))
            except:
                #per seconds MS SQL counters return no data when they are empty
                if (counter.path.endswith("/sec")):
                    self.results_builder.add_absolute_result(PluginMeasurement(
                        key=counter.timeseriesKey,
                        value=0
                    ))
                else:
                    log.info(f"Error when quering {counter.path} {counter.timeseriesKey}")
                    log.info(self, exc_info=1)

    def close(self, **kwargs):
        if sys.platform != "win32":
            return
        win32pdh.CloseQuery(self.q)
