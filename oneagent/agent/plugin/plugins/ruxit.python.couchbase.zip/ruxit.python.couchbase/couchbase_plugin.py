import requests
import json
import logging
from ruxit.api.data import PluginMeasurement
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.snapshot import pgi_name ,parse_port_bindings
import ruxit.api.exceptions
from ruxit.api.selectors import ListenPortSelector, EntityType
from collections import defaultdict, namedtuple



logger = logging.getLogger(__name__)



MetricDesc = namedtuple('MetricDesc', ['timeseries_key','entity'])


class CouchbasePlugin(BasePlugin):


    def initialize(self, **kwargs):

        self.log_master_error = False
        self.orchestrator = ''
        config = kwargs['config']
        self.auth = None
        if 'auth_user' in config and 'auth_password' in config:
            self.auth = (config['auth_user'], config['auth_password'])
        if config['port'] == '':
            # use default value that is shown
            self.url = 'http://localhost:8091'
            self.port=8091
        else:
            self.url="http://localhost:%s"%config['port']
            self.port=int(config['port'])

        self.timeseries = kwargs['json_config']['metrics']

        self.process_types = kwargs['activation_context'].value.process_types
        self.old_version_printed = False
        self.initializeMetrics()


    def initializeMetrics(self):
        self.metrics = defaultdict(list)
        for metric in self.timeseries:
            key = metric['timeseries']['key']
            entity = "PROCESS_GROUP_INSTANCE"
            if 'entity' in metric:
                    entity = metric['entity']
            if 'source' in metric:
                 source = metric['source']['type']
            else:
                #status metrics are not consider here
                continue
            self.metrics[source].append(MetricDesc(timeseries_key=key,entity=entity))


    def query(self, **kwargs):
        self.httpSession = requests.Session()
        self.process_snapshot = kwargs['process_snapshot']
        self.port_bindings = self.getBindings()


        #self.pgi = self.find_single_process_group(pgi_name('Couchbase'))
        #self.pgi_id = self.pgi.group_instance_id
        json_default = self.read('/pools/default')
        json_buckets = self.read('/pools/default/buckets')
        try:
            json_cluster_info = self.read('/pools/default/terseClusterInfo')
        except:
            #old couchbase doesn't support cluster info (older than 4.3)
            if not self.old_version_printed:
                self.old_version_printed = True
                logger.info("Cluster info is not supported by this Couchbase server.")
            json_cluster_info = {}

        self.getNodeStats(json_default)

        if self.isMaster(json_default,json_cluster_info):
            self.getBuckets(json_buckets)
            #main cluster status
            self.statusStats(json_default)
            self.ramPercentageUsage(json_default)
            # bucktes count per type
            self.bucketCount(json_buckets)
            self.bucketStats()
            self.diskStatus(json_buckets)


            if 'storageTotals' in json_default:
                logger.debug("storageTotals detected")
                json_storage_totals=json_default['storageTotals']

                self.ramPercentageUsage(json_storage_totals)
                #hdd stats per cluster
                self.__stats("hdd", "hdd", json_storage_totals)
                #ram stats per cluster
                self.__stats("ram", "ram", json_storage_totals)


    def isMaster(self,json_default,json_cluster_info)->bool:
        #the main node (reporting node) is cluster orchestrator node
        orchestrator = json_cluster_info.get('orchestrator')
        nodes = json_default.get('nodes')
        if nodes is None:
            if not self.log_master_error:
                self.log_master_error = True
                logger.info('Unable to detect master node for couchbase cluster: nodes are None')
            return False
        if orchestrator is not None:
            found = False
            for node in nodes:
                if orchestrator == node.get('otpNode'):
                    found = True
                    break
            if not found:
                orchestrator = None
        if orchestrator is None:
            # find dummy orchestrator
            up_time = -1
            for node in nodes:
                node_up_time = int(node.get('uptime', '0'))
                if node_up_time > up_time:
                    up_time = node_up_time
                    orchestrator = node.get('otpNode')
        self.log_master_error = False
        #find thisNode
        for node in nodes:
            thisNode = node.get('thisNode')
            if thisNode == True:
                otpNode = node.get('otpNode')
                if (orchestrator != self.orchestrator):
                    self.orchestrator = orchestrator
                    logger.info(f"Couchbase master detection: orchestrator {orchestrator}; otpNode {otpNode}")
                return orchestrator == otpNode
        return False


    def getNodeStats(self,json):
        if 'nodes' in json:
            for node in json['nodes']:
                if 'thisNode' in node and node['thisNode']== True:
                    self.statusStatsPerNode(node)
                    self.__stats("interestingStats", "interestingStats", node)
                    self.__stats("systemStats", "systemStats", node)
                    return
                else:
                    continue



    def getBuckets(self,json):
        self.lBuckets =[]
        for bucket in json:
            if "name" in bucket:
                self.lBuckets.append(bucket["name"])


    def getEntityType(self,metricDesc):
        entity=getattr(metricDesc, 'entity')
        if entity == "PROCESS_GROUP":
            return EntityType.PROCESS_GROUP
        else:
            return EntityType.PROCESS_GROUP_INSTANCE


    def diskStatus(self,json):
        diskFetches=[]
        for bucket in json:
            self.__stats('liveview', 'basicStats', bucket, {"bucket":bucket['name']})
            try:
                diskFetches.extend([bucket['basicStats']['diskFetches']])
            except KeyError:
                #memcached case
                pass
        #fake json only sum so it is per minute
        buckets= {"basicStats":{"diskFetches":diskFetches}}
        self.__stats("basicStats", "basicStats", buckets)



    def bucketCount(self,json):
        memcached=0
        membase =0
        for bucket in json:
            if "bucketType" in bucket:
                if 'memcached' == bucket["bucketType"]:
                    memcached +=1
                elif 'membase' == bucket["bucketType"]:
                    membase +=1


        metricDesc=self.metrics["count_memcached"][0]
        ts = getattr(metricDesc, 'timeseries_key')
        entityType=self.getEntityType(metricDesc)
        self.results_builder.add_absolute_result(
            PluginMeasurement(dimensions={}, key=ts, value=memcached, entity_selector=ListenPortSelector(self.port, self.process_types, entityType))
        )
        metricDesc=self.metrics["count_membase"][0]
        ts = getattr(metricDesc, 'timeseries_key')
        entityType=self.getEntityType(metricDesc)
        self.results_builder.add_absolute_result(
            PluginMeasurement(dimensions={}, key=ts, value=membase, entity_selector=ListenPortSelector(self.port, self.process_types, entityType))
        )


    def statusStatsPerNode(self,json):
        temp_json={"node.status":{}}
        if "status" in json:
            if json['status'] == 'healthy':
                temp_json["node.status"]['healthy']=1
            elif json['status'] == 'unhealthy':
                temp_json["node.status"]['unhealthy']=1
            elif json['status'] == 'warmup':
                temp_json["node.status"]['warmup']=1
            self.__stats("node.status", "node.status", temp_json)


    def ramPercentageUsage(self,json):
        if 'ram' in json:
            ram=json['ram']
            try:
                value=(ram['usedByData']/ram['quotaUsed'])*100
            except ZeroDivisionError:
                value=0
            temp_json={'ram':{'percentageUsage':value}}
            self.__stats('ram', 'ram', temp_json)


    def statusStats(self,json):
        nodes=json['nodes']
        healthy=0
        unhealthy=0
        warmup=0
        for node in nodes:
            if 'status' in node:
                status = node['status']
                if status == "healthy":
                    healthy +=1
                elif status == "unhealthy":
                    unhealthy +=1
                elif status =="warmup":
                    warmup +=1
        temp_json={"cluster.status":{"warmup":warmup,"healthy":healthy,"unhealthy":unhealthy}}
        self.__stats("cluster.status", "cluster.status", temp_json)

    def bucketStats(self):
        swap_used=[]
        gets=[]
        sets=[]
        ops=[]
        curr_items=[]
        ep_tmp_oom_errors=[]
        ep_oom_errors=[]
        ep_cache_miss_rate=[]
        ep_num_value_ejects=[]

        for bucket in self.lBuckets:
            json_bucket = self.read('/pools/default/buckets/%s/stats?zoom=minute' % (bucket))
            op_dict = json_bucket.get('op', {})
            samples = op_dict.get('samples')
            if not samples:
                continue
            self.__stats('liveview', 'samples', op_dict, {"bucket":bucket})
            if "swap_used" in samples:
                swap_used.extend(samples['swap_used'])
            if "cmd_get" in samples:
                gets.extend(samples["cmd_get"])
            if "cmd_set" in samples:
                sets.extend(samples["cmd_set"])
            if "ops" in samples:
                ops.extend(samples["ops"])
            if "curr_items" in samples:
                #all bucket sum
                length=len(samples["curr_items"])
                curr_items.extend([samples["curr_items"][length-1]])
            if "ep_tmp_oom_errors" in samples:
                #all bucket sum per second
                ep_tmp_oom_errors.extend(samples["ep_tmp_oom_errors"])
            if "ep_oom_errors" in samples:
                #all bucket sum per second
                ep_oom_errors.extend(samples["ep_oom_errors"])
            if "ep_cache_miss_rate" in samples:
                #avg divide by 60
                ep_cache_miss_rate.extend(samples['ep_cache_miss_rate'])
            if 'ep_num_value_ejects' in samples:
                #sum and per minute
                ep_num_value_ejects.extend(samples['ep_num_value_ejects'])

        #fake json
        temp_json= {"samples":{"swap_used":swap_used,"cmd_get":gets,"cmd_set":sets,"ops": ops ,"curr_items": curr_items,"ep_tmp_oom_errors":ep_tmp_oom_errors,
                        "ep_oom_errors":ep_oom_errors,'ep_cache_miss_rate':ep_cache_miss_rate,'ep_num_value_ejects':ep_num_value_ejects}}
        self.__stats('samples', 'samples', temp_json)


    def __stats(self, metric_type, section, parent_json, dimensions={}):
        json = parent_json[section]
        metricsDescs=self.metrics[metric_type]
        for metricDesc in metricsDescs:
            ts = getattr(metricDesc, 'timeseries_key')
            metric = ts[ts.rfind('.') + 1:]
            logger.info(metric)
            if metric in json:
                value=json[metric]
                if isinstance(value, list):
                    if len(value)==0:
                        continue
                    if metric in {'curr_items', 'diskFetches', 'ep_num_value_ejects', ' disk_write_queue'}:
                        value = sum(value)
                    elif metric == 'swap_used':
                        value = max(value)
                    else:
                        value = sum(value)/60
                logger.info("metric: %s  found: %s", metric,str(value))
                entityType=self.getEntityType(metricDesc)
                self.results_builder.add_absolute_result(
                    PluginMeasurement(dimensions=dimensions, key=ts, value=value, entity_selector=ListenPortSelector(self.port, self.process_types, entityType))
                )
            else:
                logger.info("metric: %s not found dimensions %s", metric,str(dimensions))


    def read(self, path):
        try:
            response =  self.httpSession.get(
                self.url + path,
                auth=self.auth,
                verify=False,
                timeout=30)
        except (requests.exceptions.MissingSchema, requests.exceptions.InvalidSchema, requests.exceptions.InvalidURL) \
                as ex:
            raise ruxit.api.exceptions.ConfigException('URL: "%s" does not appear to be valid' % self.url) from ex
        except requests.exceptions.Timeout as ex:
            logger.info("Port bindings: %s", self.port_bindings)
            raise ruxit.api.exceptions.ConfigException('Timeout on connecting with "%s"' % self.url) from ex
        except (
                requests.exceptions.RequestException, requests.exceptions.ConnectionError, requests.exceptions.HTTPError) as ex:
            logger.info("Port bindings: %s", self.port_bindings)
            raise ruxit.api.exceptions.ConfigException('Unable to connect to "%s"' % self.url) from ex

        # HTTP unauthorized
        if response.status_code == 401:
            raise ruxit.api.exceptions.AuthException(response)

        # HTTP missing resources
        if response.status_code == 404:
            #cluster not fully configured
            if response.content.decode().find("unknown pool")!=-1:
                errorMsg = 'It seems that couchbase cluster is not fully configured'
            else:
                errorMsg = 'Content from ' + self.url + path + 'is missing'
            raise InvalidCouchbaseSearchStatsException(errorMsg)

        try:
            document = json.loads(response.content.decode())
        except (json.JSONDecodeError) as ex:
            errorMsg = 'Content from ' + self.url + path + ' does not appear to be in Couchbase stats format'
            raise InvalidCouchbaseSearchStatsException(errorMsg) from ex
        return document


    def getBindings(self, **kwargs):
        port_bindings = []

        try:
            processinfo = self.process_snapshot
            for proc in processinfo.entries:
                if 'couchbase' in proc.group_name.lower():
                    port_bindings.append(parse_port_bindings(proc))
        except:
            logger.info("Cannot get port bindings info")

        return port_bindings



class InvalidCouchbaseSearchStatsException(Exception):
    pass