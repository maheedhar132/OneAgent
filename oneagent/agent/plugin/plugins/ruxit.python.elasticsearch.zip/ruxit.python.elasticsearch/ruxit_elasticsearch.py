"""
Ruxit Elasticsearch plugin
====================

Gathers Elasticsearch stats served by the server in json format. The full description of stats is
available at https://www.elastic.co/guide/en/elasticsearch/guide/current/_cluster_health.html

Configuration includes:

 * credentials, if stats are guarded by shield plugin
 * url to stats page - the default is: "http://localhost:9200"


There are three groups of stats collected by the plugin:

 * cluster health
 * cluster stats
 * node stats

Most node stats are collected for the local node only except for `All Nodes Performance` tab, which presents data for all nodes in the monitored cluster.
Full list of metrics is specified in plugin.json
Most metrics are taken directly from Elasticsearch stats and presented as it is, without any additional computation.
The only calculated measurements are:

 * indices.search.total_time_in_millis - presented as Query, Fetch and Scroll Time
 * indices.search.total - presented as Sum of Queries, Fetches and Scrolls

Metrics belonging to relative_measures are presented as the difference between the current and the previous values.


Limitations:

 * Elasticsearch has to be configured in a way allowing connection from localhost or the URL in plugin configuration has to have proper IP address - see ES binding settings: network.host.
 * The plugin starts for each java process and it verifies if there is an Elasticsearch process - if not it throws config exception.
 * Elasticsearch running in a Docker container may require special configuration to allow connect to stats from a remote host. Depending on container network settings, plugin configuration may requre another URL to connect to stats.



"""
from collections import defaultdict, namedtuple

import requests
from ruxit.api.data import PluginMeasurement
from ruxit.api.base_plugin import BasePlugin
import ruxit.api.exceptions
import urllib.parse
import json
import logging
from ruxit.api.snapshot import parse_port_bindings, pgi_name
from ruxit.api.selectors import ListenPortSelector, EntityType, ExplicitSelector
from urllib.parse import urlparse
from ruxit.utils.docker_helper import DockerUtils
from pkg_resources import parse_version

logger = logging.getLogger(__name__)
MetricDesc = namedtuple('MetricDesc', ['timeseries_key', 'entity', 'cluster', 'relative', 'dimensions', 'ver_from', 'ver_to'])
NodeInfo = namedtuple('NodeInfo', ['id', 'name', 'address', 'master'])

class ElasticsearchPlugin(BasePlugin):
    default_timeout = 15

    def initialize(self, **kwargs):
        config = kwargs['config']
        self.activation_context = kwargs['activation_context']
        # if config url ir relative - it will be appended to localhost
        # if it is absolute - it will override http://localhost
        if config['url'] == '':
            # use default value that is shown
            self.url = 'http://localhost:9200'
        else:
            self.url = config['url']

        # ensure slash at the end
        if not self.url.endswith('/'):
            self.url += "/"

        urlstring = urlparse(self.url)
        if not urlstring.scheme.startswith('http'):
            self.url = 'http://' + self.url

        urlstring = urlparse(self.url)
        if urlstring.port:
            self.port = urlstring.port
        else:
            if urlstring.scheme == 'http':
                self.port = urlstring.port or 80
            elif urlstring.scheme == 'https':
                self.port = urlstring.port or 443
            else:
                self.port = urlstring.port or 9200

        listen_ports = self.getListenPorts(**kwargs)
        if str(self.port) not in listen_ports:
            msg = "Configured port: " + str(self.port) + " doesn't belong to Elasticsearch process. Running ports: " + str(listen_ports)
            logger.info(msg)
            raise ruxit.api.exceptions.ConfigException(msg)

        self.timeout = config.get('timeout', self.default_timeout)

        for process in kwargs['activation_context'].value.processes:
            if "DockerContainerId" in process.properties:
                self.port = DockerUtils.get_docker_external_port(process.properties, self.port)
                self.url = "{scheme}://{hostname}:{port}/".format(scheme=urlstring.scheme, hostname=urlstring.hostname,
                                                                  port=self.port)

        self.auth = None
        if 'auth_user' in config and 'auth_password' in config:
            if config['auth_user'] or config['auth_password']:
                self.auth = (config['auth_user'], config['auth_password'])

        self.verify = False

        self.timeseries = kwargs['json_config']['metrics']
        self.previous_values = {
            'search_time': None,
            'index_time': None
        }

        self.initializeMetrics()
        self.nodeInfo = defaultdict(list)
        self.esVersion = self.getVersion()

    def getVersion(self) -> str:
        ver = "0"
        try:
            values = self.read("")
            ver = values['version']['number']
        except KeyError:
            logger.info('Could\'n retrieve Elasticsearch version - assuming 0!')
        finally:
            logger.info("ES version: %s", ver)
            return ver

    def initializeMetrics(self):
        self.metrics = defaultdict(list)
        try:
            for metric in self.timeseries:
                entity = 'PROCESS_GROUP_INSTANCE'
                cluster = False
                relative = False
                ver_from = "0"
                ver_to = "9999"
                source = 'NodeStats'
                if 'entity' in metric:
                    entity = metric['entity']
                key = metric['timeseries']['key']
                dimensions = metric['timeseries']['dimensions']
                if 'source' in metric:
                    if 'type' in metric['source']:
                        source = metric['source']['type']
                    if 'cluster' in metric['source']:
                        cluster = metric['source']['cluster']
                    if 'relative' in metric['source']:
                        relative = metric['source']['relative']
                    if 'ver_from' in metric['source']:
                        ver_from = metric['source']['ver_from']
                    if 'ver_to' in metric['source']:
                        ver_to = metric['source']['ver_to']

                self.metrics[source].append(MetricDesc(timeseries_key=key, dimensions=dimensions, entity=entity,
                                                       cluster=cluster, relative=relative, ver_from=ver_from, ver_to=ver_to))
        except KeyError:
            logger.info(self, exc_info=1)

    def printMetrics(self):
        for key in self.metrics:
            logger.info("%s=%s", key, self.metrics[key])

    def getMetricDescr(self, timeseries):
        for key in self.metrics:
            ts = ''
            for metric in self.metrics[key]:
                if key == 'NodeStats':
                    ts = 'node.' + timeseries
                else:
                    ts = timeseries
                if ts == metric.timeseries_key:
                    return metric
        logger.info("Could't find metric description for %s", timeseries)
        return None

    def getMetricEntityType(self, timeseries):
        entityType = EntityType.PROCESS_GROUP_INSTANCE
        metricDesc = self.getMetricDescr(timeseries)
        if metricDesc is not None:
            if metricDesc.entity is not None:
                metricType = metricDesc.entity
                if metricType == 'PROCESS_GROUP':
                    entityType = EntityType.PROCESS_GROUP
        return entityType

    def getMetricRelative(self, timeseries):
        isRelative = False
        metricDesc = self.getMetricDescr(timeseries)
        if metricDesc is not None:
            if metricDesc.relative is not None:
                isRelative = metricDesc.relative
        return isRelative

    def findElasticsearchProc(self):
        snapshot = self.process_snapshot
        for entry in snapshot.entries:
            techs = entry.properties.get("Technologies", "").split(',')
            if "ELASTIC_SEARCH" in techs:
                return True
        return False

    def read(self, path):
        try:
            response = requests.get(
                self.url + path,
                auth=self.auth,
                verify=self.verify,
                timeout=self.timeout)
        except (requests.exceptions.MissingSchema, requests.exceptions.InvalidSchema, requests.exceptions.InvalidURL) \
                as ex:
            raise ruxit.api.exceptions.ConfigException('URL: "%s" does not appear to be valid' % self.url) from ex
        except requests.exceptions.Timeout as ex:
            logger.info("Port bindings: %s", self.port_bindings)
            raise ruxit.api.exceptions.ConfigException('Timeout on connecting with "%s"' % self.url) from ex
        except (
                requests.exceptions.RequestException, requests.exceptions.ConnectionError, requests.exceptions.HTTPError) as ex:
            logger.info("Port bindings: %s", self.port_bindings)
            raise ruxit.api.exceptions.ConfigException('Unable to connect to "%s"' % self.url) from ex

        # HTTP unauthorized
        if response.status_code == 401:
            raise ruxit.api.exceptions.AuthException(response)

        try:
            document = json.loads(response.content.decode())
        except (json.JSONDecodeError) as ex:
            errorMsg = 'Content from ' + self.url + path + ' does not appear to be in Elasticsearch stats format'
            raise InvalidElasticSearchStatsException(errorMsg) from ex
        return document

    def reportMeasurement(self, metric, value, nodeName=None):
        my_dimensions = {'cluster': self.clusterName}
        my_key = metric
        entityType = self.getMetricEntityType(metric)
        if (entityType == EntityType.PROCESS_GROUP_INSTANCE):
            id = self.activation_context.value.group_instance_id
        else:
            id = self.activation_context.value.group_id
        selector = ExplicitSelector(id, entityType)
        if (nodeName != None):
            my_dimensions['node'] = nodeName
            my_key = 'node.' + metric
        if self.getMetricRelative(metric):
            logger.debug("Reading %s as relative measure for %s on node %s of %s", value, metric, nodeName,
                         self.clusterName)
            self.results_builder.add_relative_result(
                PluginMeasurement(dimensions=my_dimensions, key=my_key, value=value, entity_selector=selector))
        else:
            logger.debug("Reading %s as absolute measure for %s on node %s of %s", value, metric, nodeName,
                         self.clusterName)
            self.results_builder.add_absolute_result(
                PluginMeasurement(dimensions=my_dimensions, key=my_key, value=value, entity_selector=selector))


    def queryClusterHealth(self, metricsDescs):
        values = self.read('_cluster/health')
        metrics = ['status']
        for metricDesc in metricsDescs:
            ts = getattr(metricDesc, 'timeseries_key')
            if 'status-' not in ts:
                metrics.append(ts)

        for metric in metrics:
            if metric in values:
                if metric == 'status':
                    metric_name = convert_status(values[metric])[0]
                    metric_value = convert_status(values[metric])[1]
                    self.reportMeasurement(metric_name, metric_value)
                else:
                    self.reportMeasurement(metric, values[metric])
            else:
                logger.info("Could not find a value for metric %s", metric)

    def isMetricSupported(self, metric):
        if parse_version(self.esVersion) >= parse_version(metric.ver_from) and parse_version(self.esVersion) <= parse_version(metric.ver_to):
            return True
        else:
            return False


    def reportMetric(self, values, metric):
        # access the value in the json by the dotted keys in the metric
        json = values
        # validate version
        if self.isMetricSupported(metric):
            for key in metric.timeseries_key.split('.'):
                if key not in json:
                    logger.info("Could not find a value for metric %s at %s", metric, key)
                    return
                else:
                    json = json[key]

            self.reportMeasurement(metric.timeseries_key, json)
        else:
            logger.debug("Metric: %s, not supported in detected Elasticsearch ver.%s. It's only supported between versions: %s - %s", metric.timeseries_key, self.esVersion, metric.ver_from,
                        metric.ver_to)


    def queryClusterStats(self, metricsDescs):
        values = self.read("_cluster/stats")
        for metric in metricsDescs:
            self.reportMetric(values, metric)

    def queryClusterState(self):
        #retrieve cluster information to create node list with its roles: data or master
        self.clusterName = 'unknown'
        self.nodeInfo = []
        try:
            values = self.read("_cluster/state")
            cluster_name = values['cluster_name']
            self.clusterName = cluster_name
            master_node = values['master_node']
            nodes = values['nodes'].keys()
            for node in nodes:
                node_name =values['nodes'][node]['name']
                node_address = values['nodes'][node]['transport_address']
                node_master = False
                if node == master_node:
                    node_master = True

                self.nodeInfo.append(NodeInfo(id=node, name=node_name, address=node_address, master=node_master))
        except KeyError:
            logger.info('Could\'n retrieve cluster state info!')

    def viewClusterState(self):
        logger.info('Cluster name: %s', self.clusterName)
        for node in self.nodeInfo:
            logger.info('Node id: %s, name: %s, address: %s, master: %s', node.id, node.name, node.address, node.master)


    def getNodeInfo(self, node_id):
        for node in self.nodeInfo:
            if node.id == node_id:
                return node

    def getNodeMaster(self):
        for node in self.nodeInfo:
            if node.master:
                return node


    def reportNodeMetric(self, values, metric, nodeName):
        # access the value in the json by the dotted keys in the metric
        json = values
        metric_key = metric.timeseries_key
        if self.isMetricSupported(metric):
            ts = getattr(metric, 'timeseries_key')
            metric_name = ts[ts.find('.') + 1:]
            #skip the first element
            for key in metric.timeseries_key.split('.')[1:]:
                if key not in json:
                    logger.info("Could not find a value for metric %s at %s", metric.timeseries_key, key)
                    return
                else:
                    json = json[key]

            self.reportMeasurement(metric_name, json, nodeName)
        else:
            logger.debug(
                "Metric: %s, not supported in detected Elasticsearch ver.%s. It's only supported between versions: %s - %s",
                metric.timeseries_key, self.esVersion, metric.ver_from,
                metric.ver_to)


    def queryLocalNodeStats(self, metricsDescs):
        # list all metrics that are read per-node
        node_metrics = []
        metrics_to_skip=['node.indices.indexing.index_time_in_millis', 'node.indices.search.local_total_time_in_millis']
        for metricDesc in metricsDescs:
            ts = getattr(metricDesc, 'timeseries_key')
            if ts not in metrics_to_skip:
                node_metrics.append(metricDesc)

        self.queryNodeStats("_nodes/_local/stats/indices,process,thread_pool,fs,transport,http,breaker,script",
                            node_metrics)

    def queryTotalTimesLocalNode(self):
        metric = 'indices.search.total_time_in_millis'
        # calculate the node.indices.search.total_time_in_millis as the sum of all times
        try:
            url = '_nodes/_local/stats/indices'
            values = self.read(url)
            for node in values["nodes"]:
                nodeValues = values["nodes"][node]
                nodeName = nodeValues['name'] + ', ' + nodeValues['host']

                search_total_time = nodeValues['indices']['search']['query_time_in_millis'] + nodeValues['indices']['search'][
                    'fetch_time_in_millis'] + nodeValues['indices']['search']['scroll_time_in_millis']
                if self.previous_values['search_time'] is not None:
                    search_diff = search_total_time - self.previous_values['search_time']
                    if search_diff >= 0:
                        self.reportMeasurement('indices.search.local_total_time_in_millis', search_diff, nodeName)
                    else:
                        logger.info("Total search time is negative, skipping value: " + str(search_diff))

                self.previous_values['search_time'] = search_total_time

                indexing_total_time = nodeValues['indices']['indexing']['index_time_in_millis']
                if self.previous_values['index_time'] is not None:
                    indexing_diff = indexing_total_time - self.previous_values['index_time']
                    if indexing_diff >= 0:
                        self.reportMeasurement('indices.indexing.index_time_in_millis', indexing_diff, nodeName)
                    else:
                        logger.info("Indexing time is negative, skipping value: " + str(indexing_diff))

                self.previous_values['index_time'] = indexing_total_time

        except KeyError:
            logger.info(self, exc_info=1)

    def queryNodeStats(self, url, nodeMetrics):
        # we currently only look at the three categories, add more if you add more metrics below
        # other available ones are os, jvm, fs, transport, http, breakers, script
        # values = self.read("_nodes/stats/indices,process,thread_pool,fs,transport,http,breaker,script")
        values = self.read(url)

        # logger.info("Had nodes: %s", values)
        for node in values["nodes"]:
            nodeValues = values["nodes"][node]
            nodeName = nodeValues['name'] + ', ' + nodeValues['host']
            # logger.info("Had: %s: %s", node, nodeValues)
            for metric in nodeMetrics:
                self.reportNodeMetric(nodeValues, metric, nodeName)

            #if the node is master report cluster health and stats
            if self.getNodeMaster():
                nodeInfo = self.getNodeInfo(node)
                if nodeInfo:
                    if nodeInfo.master is True:
                        self.queryClusterHealth(self.metrics['ClusterHealth'])
                        self.queryClusterStats(self.metrics['ClusterStats'])
            else:
                logger.info('Master node not found in the cluster, all nodes sends cluster stats and health')
                self.queryClusterHealth(self.metrics['ClusterHealth'])
                self.queryClusterStats(self.metrics['ClusterStats'])


    def queryPoolNodeStats(self, url):
        values = self.read(url)

        threadPoolMetrics = {'threads', 'queue',
                             'rejected', 'completed',
                             }

        threadPools = {'bulk', 'get',
                       'index', 'listener', 'percolate','search'}

        for node in values["nodes"]:
            nodeValues = values["nodes"][node]
            nodeName = nodeValues['name'] + ', ' + nodeValues['host']
            # also fetch metrics for thread pools
            for threadPool in threadPools:
                for threadPoolMetric in threadPoolMetrics:
                    self.reportNodeMetric(nodeValues, 'thread_pool.' + threadPool + '.' + threadPoolMetric,
                                          nodeName)

    def query(self, **kwargs):
        self.process_snapshot = kwargs['process_snapshot']
        self.port_bindings = self.getBindings()
        if not self.findElasticsearchProc():
            logger.debug('There is no Elasticsearch process running.')
            raise ruxit.api.exceptions.NothingToReportException('noElasticSearchProcess')

        self.queryClusterState()
        self.queryLocalNodeStats(self.metrics['NodeStats'])
        self.queryTotalTimesLocalNode()


    def getBindings(self, **kwargs):
        port_bindings = []

        try:
            processinfo = self.process_snapshot
            for proc in processinfo.entries:
                techs = proc.properties.get("Technologies", "").split(',')
                if "ELASTIC_SEARCH" in techs:
                    port_bindings.append(parse_port_bindings(proc))
        except:
            logger.info("Cannot get port bindings info")

        return port_bindings

    def getListenPorts(self, **kwargs):
        try:
            processinfo = kwargs['process_snapshot']
            listen_ports = []
            for proc in processinfo.entries:
                techs = proc.properties.get("Technologies", "").split(',')
                if "ELASTIC_SEARCH" in techs:
                    for process in proc.processes:
                        listen_ports.extend(process.properties.get("ListeningPorts", "").split())
                        listen_ports.extend(process.properties.get("ListeningInternalPorts", "").split())
            return listen_ports
        except:
            logger.info("Cannot get the list of listening ports")
        return []


def convert_status(raw_value):
    if raw_value == 'green':
        name = 'status-green'
        value = 1
    elif raw_value == 'yellow':
        name = 'status-yellow'
        value = 2
    elif raw_value == 'red':
        name = 'status-red'
        value = 3
    else:
        name = 'status-unknown'
    return name, value


class InvalidElasticSearchStatsException(Exception):
    pass
