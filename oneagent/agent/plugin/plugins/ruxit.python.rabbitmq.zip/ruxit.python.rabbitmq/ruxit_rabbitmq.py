from ruxit.api.data import PluginMeasurement, PluginStateMetric, PluginProperty
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.exceptions import ConfigException, AuthException
from ruxit.api.selectors import ListenPortSelector, EntityType
from contextlib import suppress
import requests
from collections import namedtuple, defaultdict, Counter
import logging
from distutils.version import StrictVersion
from ruxit.api.data import MEAttribute
from http import HTTPStatus
import string
from pathlib import PurePath

log = logging.getLogger(__name__)

MetricDesc = namedtuple('MetricDesc', ['timeseries_key', 'per_second', 'dimensions'])


class RabbitmqPlugin(BasePlugin):
    NODE_STATS_CALCULATION = {
        'mem_usage': ('_percentage', ['mem_used', 'mem_limit']),
        'fd_usage': ('_percentage', ['fd_used', 'fd_total']),
        'sockets_usage': ('_percentage', ['sockets_used', 'sockets_total']),
        'proc_usage': ('_percentage', ['proc_used', 'proc_total']),
        'disk_free_left_to_limit': ('_subtraction', ['disk_free', 'disk_free_limit'])
    }

    REMOTE_MANAGEMENT_PLUGIN_VERSION = '3.6.7'

    API_ENDPOINTS = ['/api/nodes',
                     '/api/connections',
                     '/api/channels',
                     '/api/exchanges',
                     '/api/queues',
                     '/api/consumers',
                     '/api/overview',
                     ]

    # list of endpoints that could not exists
    UNCERTAIN_API = {
        '/api/consumers'}

    def initialize(self, **kwargs):
        config = kwargs['config']
        self.timeseries = kwargs['json_config']['metrics']
        self.process_types = kwargs['activation_context'].value.process_types
        self.technologies = kwargs['json_config']['technologies']

        if config['port'] == '':
            raise ConfigException("'Port' field cannot be empty")
        self.port = config['port']
        if 'auth_user' in config:
            self.user = config['auth_user']
        else:
            raise ConfigException("'User' field is not present in configuration")
        if 'auth_password' in config:
            self.password = config['auth_password']
        else:
            raise ConfigException("'Password' field is not present in configuration")
        if 'queues' in config:
            self.queues = config['queues']

        self.queues_status = None
        self.timeout = int(config.get('timeout', "10"))
        self._recognize_connection()
        self._initialize_metrics()
        self.topN_queues = self._initialize_topN_queues()
        self.cluster_nodes: list[str] = []

    def _construct_connection_url(self, protocol):
        return '{protocol}://127.0.0.1:{port}'.format(protocol=protocol, port=self.port)

    def _recognize_connection(self):
        url_ssl = self._construct_connection_url("https")
        url_reqular = self._construct_connection_url("http")
        try:
            response = requests.get(url_ssl, auth=(self.user, self.password), verify=False, timeout=self.timeout)
            if response.status_code == HTTPStatus.OK:
                self.url = url_ssl
                return
        except:
            pass
        try:
            response = requests.get(url_reqular, auth=(self.user, self.password), timeout=self.timeout)
            if response.status_code == HTTPStatus.OK:
                self.url = url_reqular
                return
        except:
            pass
        raise ConfigException(
            'Unable to connect to rabbitmq: {url} nor {url_ssl}!'.format(url=url_reqular, url_ssl=url_ssl))

    def _initialize_metrics(self):
        self.metrics = defaultdict(list)
        self.cluster_metrics = []
        self.topN_queues_metrics = []
        try:
            for metric in self.timeseries:
                series = metric.get("timeseries", metric.get('statetimeseries', None))
                if series == None:
                    continue
                key = series['key']
                metric_type = metric['source']['type']
                if metric_type == 'other' or metric_type == 'cluster':
                    continue
                per_second = metric['timeseries']['unit'].lower().endswith('persecond')
                dimensions = metric['timeseries']['dimensions']
                dimensions = None if len(dimensions) == 0 else dimensions[0]
                if metric_type == 'cluster_messages':
                    self.cluster_metrics.append(
                        MetricDesc(timeseries_key=key, per_second=per_second, dimensions=dimensions))
                elif metric_type == 'topN_queue':
                    self.topN_queues_metrics.append(
                        MetricDesc(timeseries_key=key, per_second=per_second, dimensions=dimensions))
                else:
                    self.metrics[metric_type].append(
                        MetricDesc(timeseries_key=key, per_second=per_second, dimensions=dimensions))
        except KeyError:
            log.info(self, exc_info=1)

    def _initialize_topN_queues(self):
        self.wildcards = []
        if len(self.queues) == 0:
            return []
        queues = [queue for queue in self.queues.split(',')]
        for queue in queues:
            if queue.find("*") > -1:
                self.wildcards.append(queue)
                queues.remove(queue)

        return queues

    def report_node_health_metric(self, is_healthy):
        self.results_builder.add_absolute_result(PluginStateMetric(key='node_status', value='ok' if is_healthy else 'failed',
                                                                   entity_selector=ListenPortSelector(self.port,
                                                                                                      self.process_types,
                                                                                                      EntityType.PROCESS_GROUP_INSTANCE,
                                                                                                      technologies=self.technologies)))

    def report_new_healthcheck(self, response_json, report):
        try:
            disk_alarm = response_json['disk_free_alarm']
            mem_alarm = response_json['mem_alarm']

            is_node_healthy = not (disk_alarm or mem_alarm)
            if report:
                self.report_node_health_metric(is_node_healthy)
            return is_node_healthy
        except KeyError as e:
            log.info("RabbitMQ node does not expose " + e)
            return None

    def report_old_healthcheck(self, response_json, report):
        try:
            is_node_healthy = response_json['status'].lower() == 'ok'
            if report:
                self.report_node_health_metric(is_node_healthy)
            return is_node_healthy
        except:
            log.info('An error encountered while receiving node healthcheck status', exc_info=1)
            return None

    def get_node_health(self, node_name, report):
        response_new = requests.get(self.url + '/api/nodes/' + node_name, auth=(self.user, self.password), verify=False, timeout=self.timeout)
        if response_new.status_code == 200:
            return self.report_new_healthcheck(response_new.json(), report)
        response_old = requests.get(self.url + '/api/healthchecks/node/' + node_name, auth=(self.user, self.password), verify=False, timeout=self.timeout)
        if response_old.status_code == 200:
            return self.report_old_healthcheck(response_old.json(), report)


        log.info("Unable to gather data from api/healthchecks/node or api/nodes/" + self.node_name)
        return None


    def query(self, **kwargs):
        self.stats = dict()

        for stats_source in RabbitmqPlugin.API_ENDPOINTS:
            self._receive_stats(stats_source)

        self.node_name = self.stats.get('/api/overview', {}).get('node', None)

        if self.node_name is None:
            raise ConfigException('Unable to identify node name, check if "node" is available in /api/overview')

        self.get_node_health(self.node_name, True)
        self.node_dim = {'node': self.node_name}
        self.report_results()

        # check if this node should report cluster metrics
        cluster_reporting_node = self._evaluate_cluster_node_name()
        if self.node_name == cluster_reporting_node:
            log.info(f'Reporting cluster data on {self.node_name} from nodes {self.cluster_nodes}.')
            self.report_cluster_metrics()

    def _receive_stats(self, stats_source: string):
        try:
            response = requests.get(self.url + stats_source, auth=(self.user, self.password), verify=False, timeout=self.timeout)
            if response.status_code != 200:
                if response.status_code == 401:
                    raise AuthException
                if response.status_code == 404 and stats_source in RabbitmqPlugin.UNCERTAIN_API:
                    log.info(' data unavailable'.format(stats_source))
                    return
                raise ConfigException('Error ' + str(response.status_code) +
                                      ' while receiving ' + str(stats_source) + ' stats')
            self.stats[stats_source] = response.json()
        except requests.exceptions.ConnectionError as ex:
            raise ConfigException('Unable to connect to ' + str(self.url + stats_source))
        except requests.exceptions.Timeout:
            log.info("Timeout reading {}".format(stats_source))
            if stats_source in RabbitmqPlugin.UNCERTAIN_API:
                return
            raise ConfigException("Timeout connecting to {} endpoint".format(stats_source))

    def _evaluate_cluster_node_name(self):
        rabbitmq_version = self.stats['/api/overview']['rabbitmq_version']
        self.results_builder.add_property(PluginProperty(
            key='RabbitMQ version',
            value=rabbitmq_version,
            me_attribute=MEAttribute.CUSTOM_PG_METADATA,
            entity_selector=ListenPortSelector(self.port, self.process_types, EntityType.PROCESS_GROUP_INSTANCE,
                                               technologies=self.technologies)
        )
        )
        if StrictVersion(rabbitmq_version) > StrictVersion(RabbitmqPlugin.REMOTE_MANAGEMENT_PLUGIN_VERSION):
            self.cluster_nodes = map(lambda node: node['name'], self.stats['/api/nodes'])
            return min(self.cluster_nodes)
        else:
            self.cluster_nodes = [self.stats.get('/api/overview', {}).get('statistics_db_node', None)]
            return self.cluster_nodes[0]

    def report_results(self):
        self.report_blocked_connections()
        for metric_type in self.metrics:
            try:
                getattr(self, 'report_' + metric_type)()
            except:
                log.info(self, exc_info=1)

    def report_node_status(self):
        healthchecks = self.stats.get('/api/healthchecks/node', None)
        if healthchecks == None:
            log.info("api/healthchecks/node missing probably version of rabbitmq lover then 3.6.2")
            return
        try:
            if healthchecks['status'].lower() == 'ok':
                self.results_builder.add_absolute_result(PluginStateMetric(key='node_status', value='ok',
                                                                           entity_selector=ListenPortSelector(self.port,
                                                                                                              self.process_types,
                                                                                                              EntityType.PROCESS_GROUP_INSTANCE,
                                                                                                              technologies=self.technologies)))
            else:
                self.results_builder.add_absolute_result(PluginStateMetric(key='node_status', value='failed',
                                                                           entity_selector=ListenPortSelector(self.port,
                                                                                                              self.process_types,
                                                                                                              EntityType.PROCESS_GROUP_INSTANCE,
                                                                                                              technologies=self.technologies)))
        except:
            log.info('An error encountered while receiving node healthcheck status', exc_info=1)

    def report_blocked_connections(self):
        connections_blocked = 0
        for connection in self.stats['/api/connections']:
            try:
                if connection['state'] is 'blocked':
                    connections_blocked += 1
            except KeyError:
                log.debug('Unable to get state for connection: ' + str(connection))
        self._send_result('connections_blocked', connections_blocked, False, self.node_dim)

    def report_summary(self):
        for metric in self.metrics['summary']:
            count = 0
            for data in self.stats['/api/' + metric.timeseries_key.split('_')[0]]:
                if data['node'] == self.node_name:
                    count += 1
            self._send_result(metric.timeseries_key,
                              count,
                              metric.per_second)

    def report_node(self):
        for node in self.stats['/api/nodes']:
            if node['name'] == self.node_name:
                for metric in self.metrics['node']:
                    try:
                        self._report_node_stat(metric, node)
                    except:
                        log.info('A problem occurred while receiving ' + str(metric.timeseries_key), exc_info=1)

    def _report_node_stat(self, metric, node):
        method = RabbitmqPlugin.NODE_STATS_CALCULATION[metric.timeseries_key]
        with suppress(ZeroDivisionError):
            self._send_result(metric.timeseries_key,
                              getattr(self, method[0])(node[method[1][0]], node[method[1][1]]),
                              metric.per_second,
                              self.node_dim)

    def report_node_on_queue(self):
        node_stats = defaultdict(lambda: 0)

        for queue in self.stats['/api/queues']:
            if queue['node'] == self.node_name:
                try:
                    if queue['auto_delete'] and queue['consumers'] == 0:
                        node_stats['ad_queues_no_consumers'] += 1
                except:
                    log.info('Cannot check auto-delete condition for queue: ' + str(queue['name']))
                for metric in self.metrics['node_on_queue']:
                    try:
                        t_key = metric.timeseries_key
                        if metric.per_second is True:
                            node_stats[t_key] += queue['message_stats'][t_key[9:]]
                        else:
                            node_stats[t_key] += queue[t_key]
                    except:
                        log.debug('Node metric ' + str(metric.timeseries_key) + ' unavailable for queue '
                                  + str(queue['name']))

        for metric in self.metrics['node_on_queue']:
            self._send_result(metric.timeseries_key, node_stats.get(metric.timeseries_key, 0), metric.per_second,
                              self.node_dim)
        self._send_result('ad_queues_no_consumers', node_stats.get('ad_queues_no_consumers', 0), False, self.node_dim)

    def report_cluster_metrics(self):
        self._get_cluster_nodes_health()
        queues_status, cluster_messages = self._get_cluster_queue_stats()

        if queues_status is not None:
            for status in queues_status.most_common():
                self._send_result('cluster_queues_' + status[0], status[1], False, entity_type=EntityType.PROCESS_GROUP)

        for message, value in cluster_messages.items():
            is_per_second = not (message == 'cluster_messages_ready' or message == 'cluster_messages_unacknowledged')
            self._send_result(message, value, is_per_second, entity_type=EntityType.PROCESS_GROUP)

        for no_of in ['cluster_channels', 'cluster_connections', 'cluster_consumers', 'cluster_exchanges']:
            stat_data = self.stats.get('/api/' + no_of.split('_')[1])
            if stat_data:
                self._send_result(no_of, len(stat_data), False, entity_type=EntityType.PROCESS_GROUP)

    def _get_cluster_nodes_health(self):
        nodes_ok = 0
        nodes_failed = 0
        no_status_collected = 0
        for node in self.stats['/api/nodes']:
            try:
                node_health = self.get_node_health(node['name'], False)
                if node_health is None:
                    continue
                if node_health:
                    nodes_ok += 1
                else:
                    nodes_failed += 1
                no_status_collected += 1
            except:
                log.info('Unable to retrieve healthcheck for ' + str(node['name']))
        if len(self.stats['/api/nodes']) == no_status_collected:
            self._send_result('cluster_nodes_ok', nodes_ok, False, entity_type=EntityType.PROCESS_GROUP)
            self._send_result('cluster_nodes_failed', nodes_failed, False, entity_type=EntityType.PROCESS_GROUP)
        else:
            nodes_ok != 0 and self._send_result('cluster_nodes_ok', nodes_ok, False,
                                                entity_type=EntityType.PROCESS_GROUP)
            nodes_failed != 0 and self._send_result('cluster_nodes_failed', nodes_failed, False,
                                                    entity_type=EntityType.PROCESS_GROUP)

    def _get_cluster_queue_stats(self):
        queues_status = []
        cluster_messages = defaultdict(lambda: 0)
        for queue in self.stats['/api/queues']:

            if queue.get('idle_since', None) is None:
                if 'state' in queue:
                    queues_status.append(queue['state'])
            else:
                queues_status.append('idle')

            if self._should_report_this_queue(queue['name']):
                self._report_topN_queue(queue)

            for message_type in self.cluster_metrics:
                t_key = message_type.timeseries_key
                try:
                    if t_key == 'cluster_messages_ready' or t_key == 'cluster_messages_unacknowledged':
                        cluster_messages[t_key] += queue[t_key[8:]]
                    else:
                        cluster_messages[t_key] += queue['message_stats'][t_key[17:]]
                except:
                    log.debug('Cluster metric ' + str(t_key) + ' unavailable for queue ' + str(queue['name']))

        return Counter(queues_status), cluster_messages

    def _should_report_this_queue(self, queue_name):
        # If no configured filter is present, report every queue
        if len(self.topN_queues) == 0 and len(self.wildcards) == 0:
            return True
        if [True for card in self.wildcards if PurePath(queue_name).match(card)]:
            return True

        return queue_name in self.topN_queues

    def _report_topN_queue(self, queue):
        dimension = {'queue': queue['name']}

        for metric in self.topN_queues_metrics:
            try:
                t_key = metric.timeseries_key.split('topN_queue_')[1]
                self._send_result(
                    key=metric.timeseries_key,
                    value=(queue[t_key] if t_key in ['messages_ready', 'messages_unacknowledged', 'consumers'] else
                           queue['message_stats'][t_key]),
                    per_second=metric.per_second,
                    dim=dimension,
                    entity_type=EntityType.PROCESS_GROUP
                )
            except KeyError:
                # Inactive queues will be missing, but it's not worth polluting the logs for.
                # log.info('Unable to get t_key: ' + str(t_key) + 'for queue: ' + str(queue['name']))
                pass

    @staticmethod
    def _percentage(arg1, arg2):
        return arg1 / arg2 * 100

    @staticmethod
    def _subtraction(arg1, arg2):
        result = arg1 - arg2
        if result < 0:
            return 0
        return result

    def _send_result(self, key, value, per_second, dim=None, entity_type=EntityType.PROCESS_GROUP_INSTANCE):
        pm = self._createpm(
            key=key,
            value=value,
            dimensions=dim,
            entity_type=entity_type)

        if per_second is True:
            self.results_builder.add_per_second_result(pm)
        else:
            self.results_builder.add_absolute_result(pm)

    def _createpm(self, entity_type, *args, **kwargs):
        return PluginMeasurement(*args, entity_selector=ListenPortSelector(self.port, self.process_types, entity_type,
                                                                           technologies=self.technologies), **kwargs)
