"""
OneAgent PerfMon plugin
=====================

Gathers PerfMon stats.
More info can be found here https://msdn.microsoft.com/en-us/library/windows/desktop/aa373214(v=vs.85).aspx

"""

from collections import namedtuple, defaultdict
from enum import Enum

from ruxit.api.data import PluginMeasurement
from ruxit.api.selectors import ExplicitPgiSelector
from ruxit.api.base_plugin import BasePlugin
import logging
import time
import sys
import importlib
from typing import Callable

if sys.platform == "win32":
    import win32pdh

log = logging.getLogger(__name__)

ProcessKeyTuple = namedtuple("ProcessKeyTuple", ["pid", "key"])


class AutoHandle:
    def __init__(self, handle, close: Callable[[any], None]):
        self._handle = handle
        self._close = close

    def close(self):
        if self._handle:
            self._close(self._handle)
            self._handle = 0

    def __del__(self):
        self.close()

    @property
    def handle(self):
        return self._handle

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()


class CounterType(Enum):
    REGULAR = 0
    RELATIVE = 1
    INCREMENTAL = 2


class CounterDesc:
    def __init__(self, path, handle, key, metric_source):
        self.path = path
        self.handle = handle

        if 'delta' in metric_source:
            self.is_relative = CounterType.RELATIVE
        elif 'differentialDelta' in metric_source:
            self.is_relative = CounterType.INCREMENTAL
        else:
            self.is_relative = CounterType.REGULAR
        self.key = key

    def is_ok_to_send(self, old_value, new_value):
        #TODO

        if self.is_relative == CounterType.REGULAR:
            return True, new_value
        elif old_value == -1:
            return False, new_value
        elif self.is_relative == CounterType.INCREMENTAL:
            return_value = new_value if new_value != old_value else 0
            return True, return_value
        elif self.is_relative == CounterType.RELATIVE:
            return_value = new_value - old_value
            return return_value > 0, return_value
        return True, new_value


class GroupDesc:
    def __init__(self):
        self.processes = {}
        self.instances_data = {}

    def __str__(self):
        return 'GroupDesc: PROCESSES: {processes} IDATA: {idata}'.format(idata=self.instances_data, processes=self.processes)

    def __repr__(self):
        return self.__str__();


class InstanceData:
    def __init__(self, id):
        self.pid = id
        self.counters: [CounterDesc]

    def __str__(self):
        return 'InstanceData ID {id}, COUNTERS {counters}'.format(id=self.id, counters=self.counters)

    def __repr__(self):
        return self.__str__()


class CounterForInstanceError(Exception):
    pass


"""
Namedtuple that is used for storing details about particular performance counter: whole path including object and metric name,
handle to counter and corresponding timeseries key.
"""

class PerfMonPlugin(BasePlugin):
    """
    PerfMonPlugin plugin class. This plugin is stateful - initialize and close methods are defined
    in order to maintain one PDH query for the lifetime of the plugin.
    """

    metrics = []

    pdh_query = -1
    MAX_TRIES = 5
    WAIT_SECONDS = 1

    def initialize(self, **kwargs):
        """
        Plugin initialization.
        This method includes opening PDH query, getting instance names from snapshot and
        parsing plugin.json file in order to add all counters to query.
        """
        if sys.platform == "win32":
            PerfMonPlugin.metrics = kwargs["json_config"]["metrics"]
            self.groups_to_desc = defaultdict(GroupDesc)
            self.old_values = {}
            self.current_values = {}
            self.reloaded_module = False

    def prepare(self, snapshot, valid_types):
        self.groups_to_desc.clear()

        for entry in snapshot.entries:
            if entry.process_type not in valid_types:
               continue
            for process in entry.processes:
                self.groups_to_desc[process.process_name].processes[process.pid] = entry.group_instance_id

        for group_name in self.groups_to_desc.keys():
            self.prepare_instances_data(group_name)
            self.prepare_identification_queries(group_name)

    def query(self, **kwargs):
        types = kwargs['json_config']['processTypes']
        if sys.platform == "win32":
            try:
                self.execute_query(types)
            except CounterForInstanceError as e:
                self.reloaded_module = True
                importlib.reload(win32pdh)
                time.sleep(10)
                try:
                    self.execute_query(types)
                except:
                    pass
            finally:
                self.cleanup()

    def execute_query(self, types):
        with self.prepare_query() as pdh_query:
            self.pdh_query = pdh_query
            self.prepare(self.query_snapshot, types)

            self.collect_counters()
            self.identify_counters()
            #always sleep to collect /sec queries
            time.sleep(1)
            log.debug("%s", self.groups_to_desc)
            self.process_counters()

    def cleanup(self):
        self.old_values = self.current_values.copy()
        self.current_values.clear()
        self.reloaded_module = False

    def process_counters(self):
        while_iterations = 1
        for group_name, group_desc in self.groups_to_desc.items():
            for instance_it, instance_data in enumerate(group_desc.instances_data.values()):
                for counter_it, counter in enumerate(instance_data.counters):
                    try:
                        while_iterations = self.process_counter(group_name, instance_data.pid, counter, while_iterations)
                    except CounterForInstanceError as ex:
                        raise ex from None
                    except Exception as e:
                        pass

    def process_counter(self, group_name, pid, counter, while_iterations):
        group_id = self.groups_to_desc[group_name].processes[pid]
        while True:
            try:
                value = self.get_value_for_handle(counter.handle)[1]
                ok_to_send, new_value = counter.is_ok_to_send(self.get_old_value(pid, counter.key), value)
                self.current_values[ProcessKeyTuple(pid, counter.key)] = value
                if new_value != -1 and ok_to_send:
                    self.send_result(new_value, pid, group_id, counter)
                break
                PerfMonPlugin.remove_counter(counter.handle)
            except:
                if while_iterations < self.MAX_TRIES:
                    log.info("Failure on query %s, query retry no %s", counter.path, while_iterations)
                    self.collect_counters()
                    while_iterations = while_iterations + 1
                    time.sleep(self.WAIT_SECONDS)
                else:
                    log.info("Exceeded number of retries!", exc_info=1)
                    raise CounterForInstanceError from None

        return while_iterations

    def get_old_value(self, pid, key):
        return self.old_values.get(ProcessKeyTuple(pid, key), -1)

    def send_result(self, value, pid, group_id, counter):
        self.results_builder.add_absolute_result(PluginMeasurement(
            key=counter.key,
            value=value,
            dimensions={"rx_pid": f'{pid:X}'},
            entity_selector=ExplicitPgiSelector(group_id)))

    def identify_counters(self):
        for group in self.groups_to_desc.values():
            for it, identification_counter in enumerate(group.identification_counters):
                if win32pdh.ValidatePath(identification_counter.path) == 0:
                    try:
                        value = self.get_value_for_handle(identification_counter.handle)
                        group.instances_data[it].pid = int(value[1])
                    except Exception as e:
                        log.info("Error on query {path} : {e}".format(path=identification_counter.path, e=str(e)))
                        raise CounterForInstanceError from e

    def prepare_identification_queries(self, group_name):
        group_identification_handlers = []
        for pid_index, pid in enumerate(self.groups_to_desc[group_name].processes):
            group = self.strip_executable(group_name)
            if (pid_index != 0) and (group_name is not None or group_name != ""):
                group += "#" + str(pid_index)
            identification_path = '\\Process({group})\\ID Process'.format(group=group)
            tmp = win32pdh.ValidatePath(identification_path)
            if tmp == 0:
                counter_handle = self.add_counter(identification_path)
                group_identification_handlers.append(CounterDesc(identification_path, counter_handle, key=0, metric_source={}))
        self.groups_to_desc[group_name].identification_counters = group_identification_handlers

    def prepare_instances_data(self, group_name):
        expected_instances_count = len(self.groups_to_desc[group_name].processes)
        current_instances_count = len(self.groups_to_desc[group_name].instances_data.keys())
        if current_instances_count < expected_instances_count:
            self.add_counters_for_instance(group_name, current_instances_count)
            self.prepare_instances_data(group_name)

    def add_counters_for_instance(self, group_name, instance_number):
        process = self.strip_executable(group_name)
        if instance_number != 0:
            process = process + "#" + str(instance_number)
        counter_list = []
        for metric in self.metrics:
            parsed_metric = metric['source']['query'].split("()")
            counter_path = '{type}({app}){query}'.format(type=parsed_metric[0], app=process, query=parsed_metric[1])
            if win32pdh.ValidatePath(counter_path) == 0:
                try:
                    counter_handle = self.add_counter(counter_path)
                    desc = CounterDesc(counter_path, counter_handle, key=metric['timeseries']['key'], metric_source=metric['source'])
                    counter_list.append(desc)
                except Exception as e:
                    log.info("Error on query {path}: {e}".format(path=counter_path, e=str(e)))
                    if not self.reloaded_module:
                        raise CounterForInstanceError from e
        instance_data = InstanceData(instance_number)
        instance_data.counters = counter_list
        self.groups_to_desc[group_name].instances_data[instance_number] = instance_data

    @staticmethod
    def get_value_for_handle(handle):
        return win32pdh.GetFormattedCounterValue(handle, win32pdh.PDH_FMT_DOUBLE)

    @staticmethod
    def remove_counter(handle):
        win32pdh.RemoveCounter(handle)

    def close(self, **kwargs):
        self.close_query()

    def collect_counters(self):
        try:
            win32pdh.CollectQueryData(self.pdh_query.handle)
        except Exception as e:
            log.info("Error collecting query data: " + str(e))

    @staticmethod
    def strip_executable(process_name):
        if process_name.lower().endswith(".exe"):
                return process_name[:-4]
        return process_name

    def prepare_query(self):
        return AutoHandle(win32pdh.OpenQuery(), win32pdh.CloseQuery)

    def close_query(self):
        try:
            self.pdh_query.close()
        except:
            pass

    def add_counter(self, path):
        return win32pdh.AddEnglishCounter(self.pdh_query.handle, path)

